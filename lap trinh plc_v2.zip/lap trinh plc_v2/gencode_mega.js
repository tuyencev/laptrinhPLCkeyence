/* gencode_mega.js
 * Bản port của gencode_picv3.js (CCS C / PIC16F877A) sang Arduino Mega 2560 (.ino).
 * Giữ nguyên: các block jig_*, track/CASE, compile() -> {tr,ks,issues}, gen(r) -> chuỗi mã.
 * Lõi: trk_run[] / tk_state[] / tk_t[] / tk_entry[] + go(); Timer1 CTC 100ms (ISR chỉ báo cờ).
 *
 * Địa chỉ chân: 'D0'..'D53' (chân số), 'A0'..'A15' (chân analog dùng như số), '595:n' (74HC595) hoặc số n (= 595:n) cho ngõ ra.
 *   {name, type:'in'  , f:{addr:'D22'}}
 *   {name, type:'out' , f:{addr:'D30' | '595:5'}}
 *   {name, type:'v52' , f:{addr:<out>, home:<in|Dnn>, work:<in|Dnn>}}     van 1 cuộn  (W = bật, H = tắt)
 *   {name, type:'v53' , f:{a1:<out>, a2:<out>, home:.., work:..}}         van 2 cuộn  (W = a2 bật, H = a1 bật)
 *   {name, type:'var' , f:{addr:'ten_bien'}}                              biến uint16_t
 *   {name, type:'motor', f:{cw:'D2' (STEP), ccw:'D3' (DIR), servo:<out> (Servo ON/ENABLE), clr:<out>, org:<in|Dnn>, stp/alm/lcw/lccw:<in|Dnn>}, orgp:'v_bd gia_toc giam_toc toc_do', rows:[{tg,ac,de,sp}]}
 *        (dùng chung khai báo với PLC; AccelStepper, tọa độ = bước, tốc độ = bước/s, gia tốc Hz/ms x 1000 = bước/s²)
 *   {name, type:'lcd' , f:{addr:'0x27', cols:16, rows:2}}                 LCD I2C (chỉ 1 cái; chiếm D20/D21)
 * Chân dành riêng: D0/D1 (Serial USB) và 3 chân 74HC595 (P595 bên dưới).
 * Cần sẵn các biến toàn cục như bên PLC: devices, tabs, ws, act, $, Blockly.
 * KHÔNG nạp chung với gencode.js / gencode_picv3.js (trùng tên compile/gen/devCheck/...).
 */

(function(){
// ───────────────────────── tiện ích ─────────────────────────
const NEGC = {'==':'!=','!=':'==','<':'>=','>':'<=','<=':'>','>=':'<'};
const OPC  = o => o==='=' ? '==' : o==='<>' ? '!=' : o;
const Tk   = s => Math.min(65535, Math.round(+s*10));          // giây -> tick 100ms
const pDev = n => devices.find(d=>d.name===n);
const val$ = id => (typeof $==='function' && $(id) && $(id).value) || '';
const ascii = s => String(s).replace(/[^\x20-\x7E]/g,'?');
const ind  = a => a.map(x=>'    '+x);
const emp  = a => a.length ? a : ['/* (trong) */'];
const IF   = (cond,th,el) => [`if (${cond}) {`,...ind(emp(th)),...(el&&el.length?['} else {',...ind(el)]:[]),'}'];

const P595 = {data:30, clk:31, latch:32};   // chân 74HC595 (số chân Arduino) - sửa theo mạch
const BL = {brk:1, alm:1, dirRev:1, sen:0};         // BLDC: mức logic (1 = HIGH) khi Brake tác động / Alarm báo lỗi / chân REV-FWD ở driver 2 chân đang chạy REV / cảm biến Đầu-Cuối-Start-Tạm dừng tác động (0 = mức thấp)
const PIN_RE = /^(D([0-9]|[1-4][0-9]|5[0-3])|A([0-9]|1[0-5]))$/i;
const RESERVED_PIN_RE = new RegExp('^D(0|1|'+P595.data+'|'+P595.clk+'|'+P595.latch+')$','i');
const OUT_RE = /^(D([0-9]|[1-4][0-9]|5[0-3])|A([0-9]|1[0-5])|595:\d{1,2}|\d{1,2})$/i;
const cpin = a => { a=String(a).toUpperCase(); return a[0]==='D' ? a.slice(1) : a; };
const si   = d => devices.filter(x=>x.type==='motor').indexOf(d);      // chỉ số motor bước trong mảng ax[]
const lcdD = () => devices.find(x=>x.type==='lcd');
const esc  = s => ascii(s).replace(/["\\]/g,'?');   // 'D22'->'22', 'A3'->'A3' (dùng trong mã C)

// tín hiệu vào (tên input đã khai báo hoặc chân Dnn/Ann) -> biểu thức C 0/1
function pSig(a){
  a=String(a||'').trim(); const d=devices.find(x=>x.type==='in'&&x.name.toUpperCase()===a.toUpperCase());
  if(d)return d.name;
  if(PIN_RE.test(a)&&!RESERVED_PIN_RE.test(a))return `rd(${cpin(a)})`;
  return null;
}
// ghi 1 ngõ ra (595:idx | số | Dnn/Ann) -> câu lệnh C
function pWr(a,v){
  a=String(a||'').trim(); let m;
  if((m=/^595:(\d+)$/.exec(a))||(m=/^(\d+)$/.exec(a)))return `data595[${m[1]}] = ${v};`;
  if(PIN_RE.test(a))return `wr(${cpin(a)}, ${v?1:0});`;
  return null;
}
// khoá địa chỉ chuẩn hoá dùng trong gói trạng thái gửi PC: 'PIN_B1' hoặc '595:3' (null nếu không hợp lệ)
function inKey(a){
  a=String(a||'').trim(); const d=devices.find(x=>x.type==='in'&&x.name.toUpperCase()===a.toUpperCase());
  if(d)a=String(d.f.addr||'').trim();
  return PIN_RE.test(a)?a.toUpperCase():null;
}
function outKey(a){
  a=String(a||'').trim(); let m;
  if((m=/^595:(\d+)$/.exec(a))||(m=/^(\d+)$/.exec(a)))return +m[1]<24?'595:'+(+m[1]):null;
  return PIN_RE.test(a)?a.toUpperCase():null;
}
// hành động van: A = 'W' (làm việc) | 'H' (về home)
function pVl(d,A){
  const w=A==='W';
  if(d.type==='v52')return [pWr(d.f.addr,w?1:0)].filter(Boolean);
  if(d.type==='v53')return [pWr(d.f.a1,w?0:1),pWr(d.f.a2,w?1:0)].filter(Boolean);   // W: a2 bật / H: a1 bật
  return [];
}

// tên trong ô chọn Input/Output của khối: 'Cam_phoi' (input/output rời, hoặc cuộn van), hoặc 'Van_kep.Home', 'Truc_X.Gốc', 'Bl1.Đầu' (chân khai báo trong cơ cấu)
function pinRef(n,dir){
  n=String(n||'');let d=pDev(n),f=d&&DT[d.type]&&DT[d.type].f.find(x=>x[0]==='addr'&&x[3]===dir);
  if(f)return {d,k:'addr',a:d.f.addr};
  const i=n.lastIndexOf('.');if(i<0)return null;
  d=pDev(n.slice(0,i));if(!d||!DT[d.type])return null;
  f=DT[d.type].f.find(x=>x[3]===dir&&TAG[x[0]]===n.slice(i+1));
  return f?{d,k:f[0],a:d.f[f[0]]}:null;
}

// ───────────────────────── biểu thức điều kiện ─────────────────────────
function ex(b,neg,c){
 const bad=m=>{c.iss.push(['e',`Track ${c.t}: ${m}`]);return '0'};
 if(!b)return bad('có ô điều kiện bị trống.');
 const T=()=>{const k=+b.getFieldValue('TRK');c.refs.push([c.t,k,'Điều kiện']);return k};
 switch(b.type){
 case 'jig_in':{const nm=b.getFieldValue('N'),r=pinRef(nm,'i');if(!r)return bad(`input "${nm}" chưa khai báo.`);
  const s=r.k==='addr'&&r.d.type==='in'?r.d.name:pSig(r.a);if(!s)return bad(`input "${nm}" chưa gán chân hợp lệ.`);
  const on=(b.getFieldValue('LV')==='1')!==neg,lv=r.d.type==='bldc'?(r.k==='alm'?BL.alm:BL.sen):1;   // cảm biến BLDC: BẬT = tác động (mức thấp)
  return `(${s} == ${on?lv:1-lv})`}
 case 'jig_valve_at':{const d=pDev(b.getFieldValue('N')),w=b.getFieldValue('P');if(!d)return bad('van chưa khai báo.');
  const a=d.f[w==='W'?'work':'home'],s=a&&pSig(a);if(!s)return bad(`van "${d.name}" chưa khai báo cảm biến ${w==='W'?'Work':'Home'}.`);
  return `(${s} == ${neg?0:1})`}
 case 'jig_var_cmp':{const d=pDev(b.getFieldValue('V'));if(!d||d.type!=='var')return bad('biến chưa khai báo.');
  let op=OPC(b.getFieldValue('OP'));if(neg)op=NEGC[op]||op;return `(${d.f.addr} ${op} ${b.getFieldValue('N')})`}
 case 'jig_timer_ge':return `(tk_t[${c.t}] ${neg?'<':'>='} ${Tk(b.getFieldValue('T'))})`;
 case 'jig_trk_is':{const k=T();return `(trk_run[${k}] ${neg?'!=':'=='} ${b.getFieldValue('M')})`}
 case 'jig_trk_case':{const k=T(),n=b.getFieldValue('N');
  return neg?`(trk_run[${k}] != 1 || tk_state[${k}] != ${n})`:`(trk_run[${k}] == 1 && tk_state[${k}] == ${n})`}
 case 'jig_motor_is':{const d=pDev(b.getFieldValue('N')),p=b.getFieldValue('P');if(!d||d.type!=='motor')return bad('motor chưa khai báo.');
  const a=d.f[p],s=a&&pSig(a);if(!s)return bad(`motor "${d.name}" chưa khai báo chân ${p}.`);return `(${s} == ${neg?0:1})`}
 case 'jig_bldc_is':{const d=pDev(b.getFieldValue('N')),p=b.getFieldValue('P');if(!d||d.type!=='bldc')return bad('motor BLDC chưa khai báo.');
  const s=d.f[p]&&pSig(d.f[p]);if(!s)return bad(`BLDC "${d.name}" chưa khai báo chân ${p}.`);
  const lv=p==='alm'?BL.alm:BL.sen;return `(${s} == ${neg?1-lv:lv})`}
 case 'jig_not':return ex(b.getInputTargetBlock('A'),!neg,c);
 default:{const and=(b.type==='jig_and')!==neg;return '('+ex(b.getInputTargetBlock('A'),neg,c)+(and?' && ':' || ')+ex(b.getInputTargetBlock('B'),neg,c)+')'}}
}

// ───────────────────────── câu lệnh ─────────────────────────
function stm(b,c){let L=[];for(;b;b=b.getNextBlock())L=L.concat(one(b,c));return L}
function one(b,c){
 const t=c.t,nu=n=>+b.getFieldValue(n),cd=()=>ex(b.getInputTargetBlock('C'),false,c);
 const bad=m=>{c.iss.push(['e',`Track ${t}: ${m}`]);return []};
 const Fl=k=>['err_flag = 1;',`err_code = ${k};`,`err_trk = ${t};`];
 const tm=`tk_t[${t}]`;
 switch(b.type){
 case 'jig_out':{const nm=b.getFieldValue('N'),r=pinRef(nm,'o');if(!r)return bad(`output "${nm}" chưa khai báo.`);
  const w=pWr(r.a,b.getFieldValue('ST')==='1'?1:0);if(!w)return bad(`output "${nm}" chưa gán chân hợp lệ.`);return [w]}
 case 'jig_valve':{const d=pDev(b.getFieldValue('N'));if(!d)return bad('van chưa khai báo.');return pVl(d,b.getFieldValue('A'))}
 case 'jig_set_var':case 'jig_inc_var':{const d=pDev(b.getFieldValue('V'));if(!d||d.type!=='var')return bad('biến chưa khai báo.');
  const a=d.f.addr,n=nu('N');return [b.type==='jig_set_var'?`${a} = ${n};`:`${a} = ${a} + ${n};`]}
 case 'jig_after':return IF(`${tm} >= ${Tk(nu('T'))}`,stm(b.getInputTargetBlock('DO'),c));
 case 'jig_valve_go':{const d=pDev(b.getFieldValue('N')),a=b.getFieldValue('A');if(!d)return bad('van chưa khai báo.');
  const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),
        sn=pSig(d.f[a==='W'?'work':'home']);
  if(sn)return [...pVl(d,a),...IF(`${sn} == 1`,dO,IF(`${tm} >= ${T}`,to.length?to:Fl(10)))];
  c.iss.push(['w',`Track ${t}: van "${d.name}" chưa khai báo cảm biến ${a==='W'?'Work':'Home'}, dùng thời gian ${T/10} s thay cho cảm biến.`]);
  return [...pVl(d,a),...IF(`${tm} >= ${T}`,dO)]}
 case 'jig_goto':c.gotos.push([t,nu('N')]);return [`go(${t}, ${nu('N')});`];
 case 'jig_once':return IF(`tk_entry[${t}]`,[`tk_entry[${t}] = 0;`,...stm(b.getInputTargetBlock('BODY'),c)]);
 case 'jig_end':return [`trk_run[${t}] = 2;`];
 case 'jig_alarm':return Fl(nu('CODE'));
 case 'jig_if':return IF(cd(),stm(b.getInputTargetBlock('THEN'),c),stm(b.getInputTargetBlock('ELSE'),c));
 case 'jig_wait':{const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c);
  return IF(cd(),dO,IF(`${tm} >= ${T}`,to.length?to:Fl(10)))}
 case 'jig_start_trk':{const k=nu('TRK'),s=+b.getFieldValue('CASE')||0;c.refs.push([t,k,'Gọi',s]);return IF(`trk_run[${k}] != 1`,[`trk_start(${k}, ${s});`])}
 case 'jig_mgo':case 'jig_mhome':case 'jig_mhome2':{const d=pDev(b.getFieldValue('N'));if(!d||d.type!=='motor')return bad('motor chưa khai báo.');
  const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),i=si(d);
  if(b.type==='jig_mgo'){const p=nu('P'),row=(d.rows||[])[p-1];
   if(!row||!/^-?\d+$/.test(String(row.tg||'').trim()))return bad(`motor "${d.name}" điểm ${p} chưa có tọa độ đích.`);
   return [`mot_go(${i}, ${p-1});`,...IF(`mot_done(${i})`,dO,IF(`${tm} >= ${T}`,to.length?to:Fl(11)))]}
  const sn=d.f.org&&pSig(d.f.org);if(!sn)return bad(`motor "${d.name}" chưa khai báo cảm biến Gốc (ORG).`);
  const o=String(d.orgp||'').trim().split(/\s+/).map(Number),hs=o[3]>0?Math.round(o[3]):1000,ha=o[1]>0?Math.round(o[1]*1000):4000;
  return IF(`mot_home(${i}, ${sn} == 0, ${hs}, ${ha}UL)`,dO,IF(`${tm} >= ${T}`,to.length?to:Fl(12)))}
 case 'jig_bldc':{const d=pDev(b.getFieldValue('N'));if(!d||d.type!=='bldc')return bad('motor BLDC chưa khai báo.');return [`bl_${d.name}(${b.getFieldValue('A')});`]}
 case 'jig_bldc_go':{const d=pDev(b.getFieldValue('N')),a=b.getFieldValue('A');if(!d||d.type!=='bldc')return bad('motor BLDC chưa khai báo.');
  const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),
        sn=pSig(d.f[a==='1'?'end':'head']),run=`bl_${d.name}(${a});`,stop=`bl_${d.name}(3);`;
  if(sn)return IF(`${sn} == ${BL.sen}`,[stop,...dO],[run,...IF(`${tm} >= ${T}`,[stop,...(to.length?to:Fl(13))])]);
  c.iss.push(['w',`Track ${t}: BLDC "${d.name}" chưa khai báo cảm biến ${a==='1'?'Cuối':'Đầu'}, dùng thời gian ${T/10} s thay cho cảm biến.`]);
  return [run,...IF(`${tm} >= ${T}`,[stop,...dO])]}
 case 'jig_servo':{const d=pDev(b.getFieldValue('N'));if(!d||d.type!=='motor')return bad('motor chưa khai báo.');
  const w=pWr(d.f.servo,b.getFieldValue('ST')==='1'?1:0);if(!w)return bad(`motor "${d.name}" chưa khai báo chân Servo ON.`);return [w]}
 case 'jig_lcd_text':case 'jig_lcd_var':case 'jig_lcd_clear':{const L0=lcdD();if(!L0)return bad('chưa khai báo thiết bị LCD.');
  if(b.type==='jig_lcd_clear')return ['lcd_clr();'];
  const r=nu('R'),cc=nu('C');
  if(r>=(+L0.f.rows||2)||cc>=(+L0.f.cols||16))c.iss.push(['w',`Track ${t}: LCD hàng ${r}, cột ${cc} nằm ngoài màn hình.`]);
  if(b.type==='jig_lcd_text')return [`lcd_put(${r}, ${cc}, "${esc(b.getFieldValue('TXT'))}");`];
  const d=pDev(b.getFieldValue('V'));if(!d||d.type!=='var')return bad('biến chưa khai báo.');
  return [`lcd_num(${r}, ${cc}, ${Math.max(1,Math.min(6,nu('W')||5))}, ${d.f.addr});`]}
 }
 return [];
}

// ───────────────────────── kiểm tra thiết bị ─────────────────────────
function outsOf(){
 const o=[];
 devices.forEach(d=>{const f=d.f||{};
  if(d.type==='out'||d.type==='v52')o.push(f.addr);
  if(d.type==='v53')o.push(f.a1,f.a2)});
 return o.filter(Boolean);
}
function devCheck(){
 const iss=[],seen={},addr={};
 devices.forEach(d=>{const f=d.f||{};
  const chk=(k,re,req,what)=>{const a=String(f[k]||'').trim();
   if(!a){if(req)iss.push(['e',`${d.name}: thiếu ${what||'địa chỉ'}.`]);return}
   if(!re.test(a))iss.push(['e',`${d.name}: "${a}" sai định dạng (${what||'địa chỉ'}).`]);
   else if(PIN_RE.test(a)&&(RESERVED_PIN_RE.test(a)||(/^D2[01]$/i.test(a)&&devices.some(x=>x.type==='lcd'))))iss.push(['e',`${d.name}: chân ${a} đã dành cho 74HC595/Serial USB/I2C LCD trên Mega.`])};
  const sens=k=>{const a=String(f[k]||'').trim();if(a&&!pSig(a))iss.push(['e',`${d.name}: cảm biến ${k} "${a}" không phải input đã khai báo hoặc Dnn/Ann.`])};
  const used=k=>{const a=String(f[k]||'').trim().toUpperCase();if(!a)return;
   if(addr[a])iss.push(['w',`Ngõ ra ${a} khai báo cho cả "${addr[a]}" và "${d.name}".`]);addr[a]=d.name};
  if(!/^[A-Za-z_]\w*$/.test(d.name))iss.push(['e',`Tên thiết bị "${d.name}" không hợp lệ (chỉ chữ, số, gạch dưới, không bắt đầu bằng số).`]);
  if(seen[d.name])iss.push(['e',`Tên thiết bị "${d.name}" bị trùng.`]);seen[d.name]=1;
  switch(d.type){
   case 'in':chk('addr',PIN_RE,true,'chân Dnn/Ann');break;
   case 'out':chk('addr',OUT_RE,true,'ngõ ra (Dnn/Ann hoặc 595:n)');used('addr');break;
   case 'v52':chk('addr',OUT_RE,true,'ngõ ra van');used('addr');sens('home');sens('work');break;
   case 'v53':chk('a1',OUT_RE,true,'ngõ ra cuộn 1');chk('a2',OUT_RE,true,'ngõ ra cuộn 2');used('a1');used('a2');sens('home');sens('work');break;
   case 'motor':{chk('cw',PIN_RE,true,'chân STEP (Xung CW)');chk('ccw',PIN_RE,true,'chân DIR (Xung CCW)');used('cw');used('ccw');
    ['servo','clr'].forEach(k=>{if(String(f[k]||'').trim()){chk(k,OUT_RE,true,k==='servo'?'ngõ ra Servo ON':'ngõ ra xóa alarm');used(k)}});
    ['org','stp','alm','lcw','lccw'].forEach(k=>{if(String(f[k]||'').trim())sens(k)});
    (d.rows||[]).forEach((o,j)=>['tg','ac','de','sp'].forEach(k=>{const s=String((o&&o[k])||'').trim();if(s&&!/^-?\d+$/.test(s))iss.push(['e',`${d.name}: điểm ${j+1}, cột ${k} phải là số nguyên.`])}));break}
   case 'bldc':{const m3=d.mode!=='2';chk('brk',OUT_RE,true,'ngõ ra Brake');chk('fwd',OUT_RE,true,m3?'ngõ ra FWD':'ngõ ra REV/FWD');used('brk');used('fwd');
    if(m3){chk('rev',OUT_RE,true,'ngõ ra REV');used('rev')}
    ['alm','head','end','start','pause'].forEach(k=>{if(String(f[k]||'').trim())sens(k)});break}
   case 'lcd':chk('addr',/^0x[0-9a-f]{1,2}$/i,true,'địa chỉ I2C (vd 0x27)');
    if(![16,20].includes(+f.cols))iss.push(['e',`${d.name}: số cột LCD phải là 16 hoặc 20.`]);
    if(![2,4].includes(+f.rows))iss.push(['e',`${d.name}: số hàng LCD phải là 2 hoặc 4.`]);
    if(lcdD()!==d)iss.push(['e',`${d.name}: chỉ hỗ trợ 1 LCD.`]);break;
   case 'var':chk('addr',/^[A-Za-z_]\w*$/,true,'tên biến C');break;
   default:iss.push(['e',`${d.name}: loại thiết bị "${d.type}" không hỗ trợ trên Mega.`])}
 });
 return iss;
}
function syncCur(){if(act>=0)tabs[act].state=Blockly.serialization.workspaces.save(ws)}

// ───────────────────────── compile: giữ nguyên logic bản PLC (bỏ phần motor) ─────────────────────────
function compile(){
 syncCur();
 const iss=devCheck(),dT=Math.min(65535,Math.round(parseFloat(val$('deft')||10)*10));
 {const sf=val$('safe').trim();if(sf&&!pSig(sf))iss.push(['e',`Ô an toàn "${sf}" phải là tên input đã khai báo hoặc Dnn/Ann (để trống nếu không dùng).`])}
 const c={iss,refs:[],gotos:[],t:0,dT},tr=[];
 tabs.forEach((tab,t)=>{c.t=t;const w=new Blockly.Workspace(),cs={};
  try{if(tab.state)Blockly.serialization.workspaces.load(tab.state,w);
   const tops=w.getTopBlocks(true),cases=tops.filter(b=>b.type==='jig_case');
   if(cases.length<tops.length)iss.push(['w',`${tab.name}: có khối nằm ngoài CASE, sẽ bị bỏ qua.`]);
   cases.forEach(b=>{const n=+b.getFieldValue('N');if(n in cs){iss.push(['e',`${tab.name}: CASE ${n} bị trùng.`]);return}
    if(b.getDescendants(false).filter(x=>x.type==='jig_once').length>1)
     iss.push(['e',`${tab.name}, CASE ${n}: chỉ được dùng 1 khối "Khi vào CASE" trong mỗi CASE (gộp các việc vào cùng một khối).`]);
    cs[n]={title:b.getFieldValue('T'),L:stm(b.getInputTargetBlock('BODY'),c)}})}finally{w.dispose()}
  if(!(0 in cs))iss.push(['e',`${tab.name}: cần có CASE 0 (điểm bắt đầu).`]);
  tr[t]=cs});
 if(!tabs.length)iss.push(['w','Chưa có track nào. Bấm "+ Track".']);
 else if(!tabs.some(x=>x.auto))iss.push(['e','Cần ít nhất 1 track tick "Tự chạy khi Start".']);
 if(new Set(tabs.map(x=>x.name)).size<tabs.length)iss.push(['w','Có tên track trùng nhau.']);
 for(const [t,k,w] of c.refs){
  if(k===t&&w==='Gọi')iss.push(['e',`Track ${t} tự gọi chính nó.`]);
  else if(!tabs[k])iss.push(['e',`Track ${t}: ${w} track ${k} nhưng track này không tồn tại.`]);}
 for(const [t,k,w,s] of c.refs)if(w==='Gọi'&&tabs[k]&&!(s in tr[k]))
  iss.push(['e',`Track ${t}: gọi track ${k} từ CASE ${s} nhưng track đích không có CASE ${s}.`]);
 for(const [t,n] of c.gotos)if(!(n in tr[t]))iss.push(['e',`${tabs[t].name}: chuyển sang CASE ${n} nhưng track không có CASE ${n}.`]);
 return {tr,ks:tr.map((_,i)=>i),issues:[...new Set(iss.map(JSON.stringify))].map(JSON.parse)};
}

// ───────────────────────── gen: sinh toàn bộ chương trình Arduino Mega 2560 (.ino) ─────────────────────────
function gen(r){
 const safeRaw=val$('safe').trim(),safe=pSig(safeRaw);   // chỉ nhận tên input hoặc Dnn/Ann, còn lại bỏ qua (compile đã báo lỗi)
 const U=r.ks,N=Math.max(U.length,1),L=[];
 const ins=devices.filter(d=>d.type==='in'),vars=devices.filter(d=>d.type==='var');
 // địa chỉ vào/ra báo lên PC: khoá của các dòng IN/OUT trong gói trạng thái (dashboard khớp theo địa chỉ này)
 const IN_A=[],OUT_A=[],addU=(A,x)=>{if(x&&!A.includes(x))A.push(x)};
 devices.forEach(d=>{const f=d.f||{};
  if(d.type==='in')addU(IN_A,inKey(f.addr));
  if(d.type==='v52'||d.type==='v53'){addU(IN_A,inKey(f.home));addU(IN_A,inKey(f.work))}
  if(d.type==='out'||d.type==='v52')addU(OUT_A,outKey(f.addr));
  if(d.type==='v53'){addU(OUT_A,outKey(f.a1));addU(OUT_A,outKey(f.a2))}
  if(d.type==='bldc'){['brk','fwd','rev'].forEach(k=>addU(OUT_A,outKey(f[k])));['alm','head','end','start','pause'].forEach(k=>addU(IN_A,inKey(f[k])))}
  if(d.type==='motor'){['servo','clr'].forEach(k=>addU(OUT_A,outKey(f[k])));['org','stp','alm','lcw','lccw'].forEach(k=>addU(IN_A,inKey(f[k])))}});
 addU(IN_A,inKey(safeRaw));
 const rdIn=a=>`rd(${cpin(a)})`;
 const rdOut=a=>/^595:/.test(a)?`o595(${a.slice(4)})`:`digitalRead(${cpin(a)})`;   // AVR: digitalRead trên chân OUTPUT trả về mức đang xuất
 const OUT_PIN=OUT_A.filter(a=>!/^595:/.test(a));
 const STP=devices.filter(d=>d.type==='motor'),NS=STP.length,LCDd=lcdD(),BLD=devices.filter(d=>d.type==='bldc');
 // nhánh lệnh PC cho stepper (chỉ sinh khi có motor): mN=pos | vN=toc do | sN dung
 const stpSet=NS?"        else if (c == 'm' || c == 'v') { if (n < NSTEP) { if (c == 'm') ax[n].moveTo(v); else ax[n].setMaxSpeed(v); } else ok = false; }\n":'';
 const bldSet=BLD.length?"        else if (c == 'b' && isDigit(s[1])) { if (n < NBLDC && v >= 0 && v <= 3) bl_cmd(n, v); else ok = false; }\n":'';
 const dbgSet="        else if (c == 'f') ok = force_cmd(s.substring(1, e).c_str(), v);\n        else if (c == 'h' && isDigit(s[1])) { if (n < NTRK) { trk_hold[n] = (v != 0); step_arm[n] = 0; send_now = true; } else ok = false; }\n        else if (c == 'k' && isDigit(s[1])) { if (n < NTRK) { trk_bp[n] = (v < 0) ? 0xFFFF : (uint16_t)v; send_now = true; } else ok = false; }\n";
 const dbgStop="    else if (c == 'n' && isDigit(s[1])) { uint8_t k = s.substring(1).toInt(); if (k < NTRK) { trk_hold[k] = 0; step_arm[k] = 1; send_now = true; } }\n    else if (c == 'f' && s[1] == 'x') f_clear();\n";
 const stpStop=NS?"    else if (c == 's' && isDigit(s[1]) && s.substring(1).toInt() < NSTEP) ax[s.substring(1).toInt()].stop();\n":'';

 L.push(`// Sinh tu Blockly - ${U.length} track (PLC Arduino Mega 2560, state-timer 100ms)`,
  '#include <string.h>','#include <stdarg.h>',...(LCDd?['#include <Wire.h>','#include <LiquidCrystal_I2C.h>']:[]),...(NS?['#include <AccelStepper.h>']:[]),'',
  `#define NTRK ${N}`,'',
  '// ---- chan 74HC595 (sua theo mach cua ban) ----',
  `#define PIN_595_DATA   ${P595.data}`,`#define PIN_595_CLK    ${P595.clk}`,`#define PIN_595_LATCH  ${P595.latch}`,'');

 // --- thiết bị ---
 ins.forEach(d=>L.push(`#define ${d.name}  rd(${cpin(d.f.addr)})`));
 vars.forEach(d=>L.push(`uint16_t ${d.f.addr} = 0;`));
 L.push('');
 L.push('// ---- force I/O (debug): 0 tha | 1 ep 0 | 2 ep 1 ----','uint8_t f_st[70];      // theo so chan Arduino (D0..D53, A0..A15 = 54..69)','uint8_t f595[24];      // theo bit 74HC595',
  'bool rd(uint8_t p) { return f_st[p] ? (f_st[p] == 2) : digitalRead(p); }','void wr(uint8_t p, bool v) { if (f_st[p]) v = (f_st[p] == 2); digitalWrite(p, v ? HIGH : LOW); }',
  'bool force_cmd(const char *name, long v);','void f_clear(void);','');

 // --- printf qua Serial ---
 L.push(String.raw`// printf cho Serial (USB, 115200)
void pf(const char *fmt, ...)
{
    char b[96];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(b, sizeof(b), fmt, ap);
    va_end(ap);
    Serial.print(b);
}
`);

 // --- LCD I2C: chỉ ghi ký tự thay đổi, tối đa lcd_budget ký tự mỗi vòng quét để không chặn xung stepper ---
 if(LCDd){const f=LCDd.f||{},ad=/^0x[0-9a-f]{1,2}$/i.test(f.addr||'')?f.addr:'0x27';
  L.push(`#define LCD_COLS ${+f.cols||16}`,`#define LCD_ROWS ${+f.rows||2}`,`LiquidCrystal_I2C lcd(${ad}, LCD_COLS, LCD_ROWS);`,
  String.raw`char lcd_buf[LCD_ROWS][LCD_COLS];   // ban sao man hinh
uint8_t lcd_budget = 1;                // so ky tu duoc ghi trong 1 vong quet

void lcd_put(uint8_t r, uint8_t c, const char *s)
{
    if (r >= LCD_ROWS) return;
    for (; *s && c < LCD_COLS; s++, c++) {
        if (lcd_buf[r][c] == *s) continue;
        if (!lcd_budget) return;       // het quota: vong quet sau ghi tiep
        lcd_budget--;
        lcd_buf[r][c] = *s;
        lcd.setCursor(c, r);
        lcd.write(*s);
    }
}

void lcd_num(uint8_t r, uint8_t c, uint8_t w, uint16_t v)
{
    char b[8];
    snprintf(b, sizeof(b), "%-*u", w, (unsigned int)v);
    lcd_put(r, c, b);
}

void lcd_clr(void)
{
    uint8_t r, c;
    for (r = 0; r < LCD_ROWS; r++)
        for (c = 0; c < LCD_COLS; c++)
            if (lcd_buf[r][c] != ' ') {
                if (!lcd_budget) return;
                lcd_budget--;
                lcd_buf[r][c] = ' ';
                lcd.setCursor(c, r);
                lcd.write(' ');
            }
}
`);}

 // --- motor (AccelStepper, chạy không chặn): Xung CW = STEP, Xung CCW = DIR; bảng điểm lấy từ cấu hình motor ---
 if(NS){
  const NPT=Math.max(1,...STP.map(d=>(d.rows||[]).length)),
   nv=(o,k,m)=>{const v=parseInt(String((o&&o[k])||'').trim(),10);return Number.isFinite(v)?v*m:0},
   tbl=(k,m)=>'{ '+STP.map(d=>'{ '+Array.from({length:NPT},(_,j)=>nv((d.rows||[])[j],k,m)).join(', ')+' }').join(', ')+' }';
  L.push(`#define NSTEP ${NS}`,`#define NPT ${NPT}`,'#define MOT_DEF_SPD 2000','#define MOT_DEF_ACC 4000UL',
   `AccelStepper ax[NSTEP] = { ${STP.map(d=>`AccelStepper(1, ${cpin(d.f.cw)}, ${cpin(d.f.ccw)})`).join(', ')} };   // (DRIVER, STEP = CW, DIR = CCW)`,
   `const long     MP_POS[NSTEP][NPT] = ${tbl('tg',1)};   // toa do dich (buoc)`,
   `const uint16_t MP_SPD[NSTEP][NPT] = ${tbl('sp',1)};   // buoc/s, 0 = mac dinh`,
   `const uint32_t MP_ACC[NSTEP][NPT] = ${tbl('ac',1000)};   // Hz/ms x 1000 = buoc/s^2, 0 = mac dinh`,
   String.raw`
// toi diem p cua bang diem; goi lai moi vong quet cung an toan
void mot_go(uint8_t i, uint8_t p)
{
    ax[i].setMaxSpeed(MP_SPD[i][p] ? MP_SPD[i][p] : MOT_DEF_SPD);
    ax[i].setAcceleration(MP_ACC[i][p] ? MP_ACC[i][p] : MOT_DEF_ACC);
    ax[i].moveTo(MP_POS[i][p]);
}
bool mot_done(uint8_t i) { return ax[i].distanceToGo() == 0; }

// ve goc theo chieu am (CCW): goi moi vong quet; hit = cam bien ORG dang tac dong -> toa do = 0, tra true
bool mot_home(uint8_t i, bool hit, uint16_t spd, uint32_t acc)
{
    if (hit) { ax[i].setCurrentPosition(0); return true; }
    ax[i].setMaxSpeed(spd);
    ax[i].setAcceleration(acc);
    ax[i].moveTo(ax[i].currentPosition() - 1000);
    return false;
}
`);}

 // --- 74HC595 (24 bit) ---
 L.push(String.raw`// ---- 74HC595 (24 bit) ----
bool data595[24];
bool o595(uint8_t i) { return f595[i] ? (f595[i] == 2) : data595[i]; }

void send_595(void)
{
    int8_t i;
    for (i = 23; i >= 0; i--) {
        digitalWrite(PIN_595_DATA, o595(i) ? HIGH : LOW);
        digitalWrite(PIN_595_CLK, LOW);
        digitalWrite(PIN_595_CLK, HIGH);
    }
    digitalWrite(PIN_595_LATCH, LOW);
    digitalWrite(PIN_595_LATCH, HIGH);
}

void init_595(void)
{
    uint8_t j;
    for (j = 0; j < 24; j++) data595[j] = 0;
    send_595();
}
`);

 // --- BLDC: bl_<ten>(c): 0 thả | 1 FWD | 2 REV | 3 Brake (driver 2 chân không có "thả": 0 = Brake) ---
 if(BLD.length){L.push('// ---- motor khong choi than ----',`#define NBLDC ${BLD.length}`,'uint8_t bl_st[NBLDC];   // lenh hien tai: 0 tha | 1 FWD | 2 REV | 3 brake','');
  BLD.forEach((d,bi)=>{const f=d.f||{},m3=d.mode!=='2';
   const wr=c=>{const o=[],W=(a,v)=>{const s=a&&String(a).trim()&&pWr(a,v);if(s)o.push(s)},run=c===1||c===2,brk=!run&&(!m3||c===3);
    W(f.brk,brk?BL.brk:1-BL.brk);
    if(m3){W(f.fwd,c===1?1:0);W(f.rev,c===2?1:0)}else if(run)W(f.fwd,c===2?BL.dirRev:1-BL.dirRev);
    return o};
   L.push(`void bl_${d.name}(uint8_t c)   // 0 tha | 1 FWD | 2 REV | 3 brake`,'{',`    bl_st[${bi}] = c;`,'    switch (c)','    {');
   [0,1,2,3].forEach(c=>L.push(`    case ${c}:`,...ind(ind(emp(wr(c)))),'        break;'));
   L.push('    }','}','')});
  L.push('// lenh tu PC: bN=c (N = thu tu motor BLDC)','void bl_cmd(uint8_t i, uint8_t c)','{','    if (c > 3) return;','    switch (i)','    {',
   ...BLD.map((d,i)=>`    case ${i}: bl_${d.name}(c); break;`),'    }','}','')}

 // --- ghi ngõ ra trực tiếp từ PC (thủ công): Dnn/Ann=v ; ngõ ra 595 dùng lệnh dNN=v (d thường) ---
 L.push('// ghi ngo ra truc tiep tu PC: ten_chan=gia_tri (tra true neu nhan ra chan)','bool set_pin_cmd(const char *name, uint16_t v)','{',
  ...OUT_PIN.map(a=>`    if (strcmp(name, "${a}") == 0) { digitalWrite(${cpin(a)}, v ? HIGH : LOW); return true; }`),
  '    return false;','}','');

 // --- lõi state-timer ---
 L.push(String.raw`// ---- loi track/state-timer (don vi 100ms) ----
// Timer1 CTC, 16MHz, chia 256: 62500 Hz -> 6250 xung = 100ms
#define TK_OCR1A 6249
uint8_t  trk_run[NTRK];        // 0 dung, 1 chay, 2 xong, 3 loi
uint16_t tk_state[NTRK];       // CASE hien tai cua tung track
uint16_t tk_t[NTRK];           // thoi gian trong CASE, don vi 100ms
uint8_t  tk_entry[NTRK];       // =1 o vong dau tien cua moi CASE
uint8_t  trk_hold[NTRK];       // =1: giu track tai CASE hien tai (debug)
uint8_t  step_arm[NTRK];       // =1: chay toi lan chuyen CASE ke tiep roi giu
uint16_t trk_bp[NTRK];         // diem dung: so CASE, 0xFFFF = khong dat
bool     err_flag = false;
uint8_t  err_code = 0;
uint8_t  err_trk  = 0;
uint8_t  run_cmd  = 1;         // 1 chay, 2 dung, 3 xoa loi (tu PC)
bool     giaotiep = false;     // =true: gui trang thai cho PC, =false: dung gui
bool     manual   = false;
uint16_t time_send_data = 0;
bool     send_now = false;     // =true: vua co thay doi -> gui goi trang thai ngay cho PC
uint8_t  send_gap = 0;         // so tick con lai truoc khi duoc gui goi su kien tiep theo
#define TK_SEND_PERIOD 2       // goi dinh ky: 2 tick = 200ms
#define TK_SEND_GAP    2       // khoang cach toi thieu giua 2 goi: 2 tick (100..200ms), chong nhieu lam tran UART
volatile bool tick_flag = false;

ISR(TIMER1_COMPA_vect)
{
    tick_flag = true;          // ISR chi bao co
}

// Chuyen CASE cua 1 track: reset thoi gian o DUY NHAT cho nay
void go(uint8_t id, uint16_t s)
{
    tk_state[id] = s;
    tk_t[id]     = 0;
    tk_entry[id] = 1;
    send_now     = true;       // doi CASE: bao PC ngay
    if (step_arm[id] || trk_bp[id] == s) { trk_hold[id] = 1; step_arm[id] = 0; }   // chay tung buoc / diem dung
}

void trk_start(uint8_t k, uint16_t start_case)
{
    trk_run[k] = 1;
    go(k, start_case);
}

// ---- nhan lenh tu PC (ket thuc bang xuong dong) ----
// Lenh: r chay | x dung | c xoa loi | g bat gui trang thai | d tat | m thu cong | a tu dong
//       fPIN=1|0 ep chan (PIN = Dnn/Ann/595:n), fPIN=-1 tha, fx tha het | hN=1|0 giu/tha track | nN chay 1 buoc | kN=CASE diem dung (-1 xoa)
//       dNN=v ghi 595 (d thuong) | Dnn/Ann=v ghi chan truc tiep | mN=pos stepper toi vi tri | vN=toc do | sN dung stepper N | bN=c BLDC N (0 tha, 1 FWD, 2 REV, 3 brake)
void process_cmd(String s)
{
    s.trim();
    if (!s.length()) return;
    char c = s[0];
    int e = s.indexOf('=');
    if (e > 0) {
        String name = s.substring(0, e);
        int n = s.substring(1, e).toInt();
        long v = s.substring(e + 1).toInt();
        bool ok = true;
        if (c == 'd' && isDigit(s[1])) { if (n < 24) data595[n] = (v != 0); else ok = false; }
${stpSet}${bldSet}${dbgSet}        else ok = set_pin_cmd(name.c_str(), v);
        if (ok) pf("OK %s=%ld\r\n", name.c_str(), v);
        else    pf("ERR Unknown pin %s\r\n", name.c_str());
    }
${stpStop}${dbgStop}    else if (c == 'r') run_cmd = 1;
    else if (c == 'x') run_cmd = 2;
    else if (c == 'c') run_cmd = 3;
    else if (c == 'g') { giaotiep = true; send_now = true; }
    else if (c == 'd') giaotiep = false;
    else if (c == 'm') { manual = true; pf("MANUAL MODE\r\n"); }
    else if (c == 'a') { manual = false; pf("AUTO MODE\r\n"); }
}
`);

 const FK=[...new Set([...IN_A,...OUT_A])];
 L.push('// ep tin hieu (debug)','void f_clear(void)','{','    memset(f_st, 0, sizeof(f_st));','    memset(f595, 0, sizeof(f595));','    send_now = true;','}','',
  'bool force_cmd(const char *name, long v)','{','    uint8_t st = (v < 0) ? 0 : (v ? 2 : 1);',
  ...FK.map(a=>/^595:/.test(a)?`    if (strcmp(name, "${a}") == 0) { f595[${a.slice(4)}] = st; send_now = true; return true; }`:`    if (strcmp(name, "${a}") == 0) { f_st[${cpin(a)}] = st; send_now = true; return true; }`),
  '    return false;','}','');

 // --- in trạng thái cho dashboard (định dạng giữ nguyên như bản PIC) ---
 L.push('void printAllStates(void)','{','    uint8_t i;','    pf("BEGIN\\r\\n");');
 vars.forEach(d=>L.push(`    pf("${d.f.addr} = %u\\r\\n", (unsigned int)(${d.f.addr}));`));
 L.push('    for (i = 0; i < NTRK; i++) pf("TRK %u run=%u case=%u t=%u\\r\\n", (unsigned int)i, (unsigned int)trk_run[i], (unsigned int)tk_state[i], (unsigned int)tk_t[i]);',
  '    pf("ERR %u code=%u trk=%u\\r\\n", (unsigned int)err_flag, (unsigned int)err_code, (unsigned int)err_trk);',
  '    pf("SYS man=%u\\r\\n", (unsigned int)manual);');
 L.push('    pf("FRC");',...FK.map(a=>/^595:/.test(a)?`    if (f595[${a.slice(4)}]) pf(" ${a}=%u", (unsigned int)(f595[${a.slice(4)}] == 2));`:`    if (f_st[${cpin(a)}]) pf(" ${a}=%u", (unsigned int)(f_st[${cpin(a)}] == 2));`),'    pf("\\r\\n");',
  '    for (i = 0; i < NTRK; i++) pf("DBG %u hold=%u bp=%d\\r\\n", (unsigned int)i, (unsigned int)trk_hold[i], (int)(trk_bp[i] == 0xFFFF ? -1 : (int)trk_bp[i]));');
 if(NS)L.push('    for (i = 0; i < NSTEP; i++) pf("STP %u pos=%ld moving=%u\\r\\n", (unsigned int)i, ax[i].currentPosition(), (unsigned int)(ax[i].distanceToGo() != 0));');
 BLD.forEach((d,i)=>{const ks=['alm','head','end','start','pause'].filter(k=>pSig(d.f[k]));
  L.push('    pf("BLD '+i+' cmd=%u'+ks.map(k=>' '+k+'=%u').join('')+'\\r\\n", (unsigned int)bl_st['+i+']'+ks.map(k=>', (unsigned int)(('+pSig(d.f[k])+') == '+(k==='alm'?BL.alm:BL.sen)+')').join('')+');')});
 IN_A.forEach(a=>L.push(`    pf("IN ${a}=%u\\r\\n", (unsigned int)${rdIn(a)});`));
 OUT_A.forEach(a=>L.push(`    pf("OUT ${a}=%u\\r\\n", (unsigned int)${rdOut(a)});`));
 L.push('    pf("END\\r\\n");','}','');

 // --- phat hien thay doi de bao PC ngay (send_now) ---
 const IO=[...IN_A.map(rdIn),...OUT_A.map(rdOut)];
 L.push(`#define NIO ${Math.max(IO.length,1)}`,'bool    io_prev[NIO];','uint8_t prev_run[NTRK];',...(BLD.length?['uint8_t bl_prev[NBLDC];']:[]),'bool    prev_err = false;','bool    prev_man = false;','',
  '// doi vao/ra, doi trang thai track, loi, thu cong -> send_now = true','void detect_changes(void)','{','    uint8_t k;','    bool v;',
  ...IO.flatMap((e,i)=>[`    v = (${e}) != 0;`,`    if (v != io_prev[${i}]) { io_prev[${i}] = v; send_now = true; }`]),
  '    for (k = 0; k < NTRK; k++) if (trk_run[k] != prev_run[k]) { prev_run[k] = trk_run[k]; send_now = true; }',
  ...(BLD.length?['    for (k = 0; k < NBLDC; k++) if (bl_st[k] != bl_prev[k]) { bl_prev[k] = bl_st[k]; send_now = true; }']:[]),
  '    if (err_flag != prev_err) { prev_err = err_flag; send_now = true; }',
  '    if (manual != prev_man)   { prev_man = manual;   send_now = true; }','}','');

 // --- từng track ---
 for(const t of U){
  L.push(`// --- TRACK ${t}: ${ascii(tabs[t].name||'')} ---`,`void trk_${t}(void)`,'{',`    switch (tk_state[${t}])`,'    {');
  Object.keys(r.tr[t]).map(Number).sort((a,b)=>a-b).forEach(n=>{
   L.push(`    case ${n}:`,...ind(ind(emp(r.tr[t][n].L))),'        break;','');});
  L.push('    default:','        err_flag = true;','        err_code = 99;',`        err_trk = ${t};`,'        break;','    }','}','');
 }

 // --- vòng quét chính ---
 const forAll=body=>['for (k = 0; k < NTRK; k++) { '+body+' }'];
 L.push('void jig_scan(void)','{','    uint8_t k;','    bool idle;','    switch (run_cmd)','    {','    case 1:',
  '        idle = true;','        for (k = 0; k < NTRK; k++) if (trk_run[k] == 1) idle = false;','        if (idle) {',
  '            err_flag = false; err_code = 0; err_trk = 0; manual = false;');
 U.forEach(t=>L.push(tabs[t].auto?`            trk_start(${t}, 0);`:`            trk_run[${t}] = 0; go(${t}, 0);`));
 L.push('        }','        break;','    case 2:',...ind(ind(forAll('trk_run[k] = 0; trk_hold[k] = 0; step_arm[k] = 0;'))),'        break;',
  '    case 3:','        err_flag = false; err_code = 0; err_trk = 0;',...ind(ind(forAll('trk_run[k] = 0; trk_hold[k] = 0; step_arm[k] = 0;'))),'        break;','    }','    run_cmd = 0;','');
 if(safe)L.push(`    // an toan: ${ascii(safeRaw)} = 0 la loi`,`    if ((${safe}) == 0) { err_flag = true; err_code = 1; err_trk = 0; }`,'');
 BLD.forEach((d,i)=>{const s=pSig(d.f.alm);if(s)L.push(`    if ((${s}) == ${BL.alm}) { err_flag = true; err_code = ${20+i}; err_trk = 0; }   // alarm driver ${ascii(d.name)}`)});
 U.forEach(t=>L.push(`    if (!err_flag && trk_run[${t}] == 1 && !trk_hold[${t}]) trk_${t}();`));
 L.push('','    if (err_flag) {',...ind(forAll('trk_run[k] = 3;')),'    }','');
 const o=outsOf();
 if(o.length||NS||BLD.length){
  L.push('    idle = true;','    for (k = 0; k < NTRK; k++) if (trk_run[k] != 0) idle = false;',
   '    // loi hoac dung: tat output','    if (err_flag || (idle && !manual)) {',...ind(o.map(a=>pWr(a,0)).filter(Boolean)),...ind(BLD.map(d=>`bl_${d.name}(3);`)),...(NS?['        for (k = 0; k < NSTEP; k++) ax[k].stop();']:[]),'    }');
 }
 L.push('}','');

 // --- setup / loop ---
 L.push('void setup()','{','    uint8_t k;','    Serial.begin(250000);','    Serial.setTimeout(5);',
  '    pinMode(PIN_595_DATA, OUTPUT); pinMode(PIN_595_CLK, OUTPUT); pinMode(PIN_595_LATCH, OUTPUT);',
  '    pinMode(LED_BUILTIN, OUTPUT);',
  ...IN_A.map(a=>`    pinMode(${cpin(a)}, INPUT);          // ${a}`),
  ...OUT_PIN.map(a=>`    pinMode(${cpin(a)}, OUTPUT); digitalWrite(${cpin(a)}, LOW);   // ${a}`),
  '    init_595();',...BLD.map(d=>`    bl_${d.name}(3);   // BLDC: ham khi khoi dong`),
  ...(LCDd?['    Wire.begin(); Wire.setClock(400000);','    lcd.init(); lcd.backlight(); lcd.clear(); memset(lcd_buf, \' \', sizeof(lcd_buf));']:[]),
  ...(NS?['    for (k = 0; k < NSTEP; k++) { ax[k].setMaxSpeed(MOT_DEF_SPD); ax[k].setAcceleration(MOT_DEF_ACC); }']:[]),
  '    digitalWrite(LED_BUILTIN, HIGH); delay(1000); digitalWrite(LED_BUILTIN, LOW);',
  '    for (k = 0; k < NTRK; k++) { trk_run[k] = 0; tk_state[k] = 0; tk_t[k] = 0; tk_entry[k] = 1; trk_bp[k] = 0xFFFF; }',
  '    noInterrupts();','    TCCR1A = 0;','    TCCR1B = (1 << WGM12) | (1 << CS12);   // CTC, chia 256','    OCR1A  = TK_OCR1A;','    TCNT1  = 0;','    TIMSK1 = (1 << OCIE1A);','    interrupts();','}','',
  'void loop()','{','    uint8_t k;','    bool tk;',
  ...(NS?['    for (k = 0; k < NSTEP; k++) ax[k].run();']:[]),
  '    noInterrupts(); tk = tick_flag; tick_flag = false; interrupts();',
  '    if (tk) {','        for (k = 0; k < NTRK; k++) { if (tk_t[k] < 65535 && !trk_hold[k]) tk_t[k]++; }',
  '        if (giaotiep) time_send_data++;','        if (send_gap) send_gap--;','    }',
  "    if (Serial.available()) process_cmd(Serial.readStringUntil('\\n'));",
  ...(LCDd?['    lcd_budget = 1;']:[]),
  '    jig_scan();','    send_595();','    detect_changes();',
  '    if (giaotiep && ((send_now && send_gap == 0) || time_send_data >= TK_SEND_PERIOD)) {',
  '        printAllStates();','        send_now = false;','        time_send_data = 0;','        send_gap = TK_SEND_GAP;','    }','}');
 return L.join('\n');
}

window.compile=compile; window.gen=gen; window.devCheck=devCheck; window.outsOf=outsOf; window.syncCur=syncCur;
window.V=t=>({st:t,pc:t,tm:t,en:t,ms:t});   // app.js (render) gọi V(t) để hiện nhãn
window.normM=d=>({axis:'1',orgp:'',rows:[{}],...d});   // app.js gọi normM cho motor đọc từ file
window.MCU_KIND='mega';   // app.js dùng để nhận biết bộ sinh Arduino Mega
})();