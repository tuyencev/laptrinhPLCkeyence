/* uploader.js - Nạp file .hex vào Arduino Mega 2560 qua Web Serial API (Chrome / Edge).
 * Giao thức: bootloader STK500v2 (Wiring) của Mega 2560, 115200 baud, tự reset board bằng DTR/RTS.
 * Dùng:  await MegaUploader.upload(port, hexText, {log(msg), progress(0..1), verify:true})
 *        port lấy từ navigator.serial.requestPort(); hàm tự mở và đóng cổng.
 */
(function(){
const PAGE=256,            // kích thước page flash ATmega2560
      APP_END=0x3E000,     // 8 KB cuối flash là bootloader, không ghi vào
      FLASH=0x40000;       // 256 KB
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const h2=n=>'0x'+n.toString(16).toUpperCase().padStart(2,'0');

// ---------- Intel HEX -> ảnh flash ----------
function parseHex(text){
 const mem=new Uint8Array(FLASH).fill(0xFF);
 let ext=0,max=-1,eof=false;
 for(const raw of String(text).split(/\r?\n/)){
  const ln=raw.trim();if(!ln)continue;
  if(ln[0]!==':')throw new Error('File .hex sai định dạng: "'+ln.slice(0,24)+'"');
  const b=[];for(let i=1;i+1<ln.length;i+=2)b.push(parseInt(ln.substr(i,2),16));
  if(b.some(Number.isNaN)||b.length!==b[0]+5)throw new Error('Dòng .hex hỏng: "'+ln.slice(0,24)+'"');
  if(b.reduce((s,x)=>s+x,0)&255)throw new Error('Sai checksum trong file .hex.');
  const n=b[0],t=b[3];
  if(t===0){const a=ext+((b[1]<<8)|b[2]);
   if(a+n>FLASH)throw new Error('File .hex vượt quá bộ nhớ flash 256 KB.');
   for(let k=0;k<n;k++)mem[a+k]=b[4+k];
   if(n&&a+n-1>max)max=a+n-1}
  else if(t===1){eof=true;break}
  else if(t===2)ext=((b[4]<<8)|b[5])<<4;
  else if(t===4)ext=((b[4]<<8)|b[5])*65536;
 }
 if(max<0)throw new Error('File .hex rỗng.');
 if(max>=APP_END)throw new Error('Chương trình ('+(max+1)+' byte) lớn hơn vùng ứng dụng của Mega 2560 ('+APP_END+' byte).');
 return {mem,end:max+1,eof};
}

// ---------- nạp ----------
async function upload(port,hexText,o={}){
 const log=o.log||(()=>{}),prog=o.progress||(()=>{}),verify=o.verify!==false;
 const img=parseHex(hexText);
 const pages=Math.ceil(img.end/PAGE);
 log('Chương trình '+img.end+' byte, '+pages+' page.');

 try{await port.open({baudRate:250000,dataBits:8,stopBits:1,parity:'none',flowControl:'none'})}
 catch(e){throw new Error('Không mở được cổng (đang bị chương trình khác dùng? hãy đóng Serial Monitor / dashboard): '+e.message)}

 const reader=port.readable.getReader(),writer=port.writable.getWriter(),q=[];
 let rxErr=null;
 const pump=(async()=>{try{for(;;){const {value,done}=await reader.read();if(done)break;if(value)for(const x of value)q.push(x)}}catch(e){rxErr=e}})();

 const need=async(n,ms)=>{const t=Date.now()+ms;
  while(q.length<n){if(rxErr)throw rxErr;if(Date.now()>t)throw new Error('timeout');await sleep(2)}};

 // gửi 1 lệnh STK500v2, trả về phần thân phản hồi (đã kiểm tra checksum và mã trạng thái)
 let seq=0;
 async function cmd(body,ms=1000){
  seq=(seq+1)&255;
  const f=[0x1B,seq,body.length>>8,body.length&255,0x0E,...body];
  let c=0;for(const x of f)c^=x;f.push(c);
  q.length=0;
  await writer.write(new Uint8Array(f));
  const end=Date.now()+ms;
  for(;;){
   await need(1,end-Date.now());
   if(q[0]!==0x1B){q.shift();continue}
   await need(5,end-Date.now());
   if(q[4]!==0x0E){q.shift();continue}
   const size=(q[2]<<8)|q[3];
   await need(6+size,end-Date.now());
   const fr=q.splice(0,6+size);
   let x=0;for(let i=0;i<fr.length-1;i++)x^=fr[i];
   if(x!==fr[fr.length-1])throw new Error('Phản hồi sai checksum.');
   if(fr[1]!==seq)continue;                       // khung cũ, bỏ qua
   const r=fr.slice(5,5+size);
   if(r[0]!==body[0])throw new Error('Phản hồi không khớp lệnh '+h2(body[0])+'.');
   if(r[1]!==0)throw new Error('Bootloader báo lỗi '+h2(r[1])+' cho lệnh '+h2(body[0])+'.');
   return r;
  }
 }
 // địa chỉ flash tính theo word; bit 31 = địa chỉ mở rộng (flash > 128 KB)
 const loadAddr=byteAddr=>{const v=((byteAddr>>>1)|0x80000000)>>>0;
  return [0x06,(v>>>24)&255,(v>>>16)&255,(v>>>8)&255,v&255]};

 try{
  log('Reset board...');
  const sig=async s=>{try{await port.setSignals(s)}catch(e){}};
  await sig({dataTerminalReady:false,requestToSend:false});await sleep(50);
  await sig({dataTerminalReady:true,requestToSend:true});await sleep(250);
  await sig({dataTerminalReady:false,requestToSend:false});await sleep(50);

  let ok=false;
  for(let i=0;i<10&&!ok;i++){
   try{const r=await cmd([0x01],400);
    log('Bootloader: '+String.fromCharCode(...r.slice(3,3+r[2])));ok=true}catch(e){}
  }
  if(!ok)throw new Error('Không bắt tay được với bootloader. Kiểm tra đã chọn đúng cổng COM của Mega 2560 chưa.');

  await cmd([0x10,200,100,25,0x20,0,0x53,3,0xAC,0x53,0,0]);        // vào chế độ lập trình
  const part=verify?0.5:1;
  log('Đang ghi flash...');
  for(let p=0;p<pages;p++){
   const a=p*PAGE;
   await cmd(loadAddr(a));
   await cmd([0x13,PAGE>>8,PAGE&255,0xC1,0x0A,0x40,0x4C,0x20,0,0,...img.mem.subarray(a,a+PAGE)],3000);
   prog((p+1)/pages*part);
  }
  if(verify){
   log('Đang kiểm tra lại...');
   for(let p=0;p<pages;p++){
    const a=p*PAGE;
    await cmd(loadAddr(a));
    const r=await cmd([0x14,PAGE>>8,PAGE&255,0x20],2000),d=r.slice(2,2+PAGE);
    for(let k=0;k<PAGE;k++)if(d[k]!==img.mem[a+k])
     throw new Error('Kiểm tra lại sai tại địa chỉ '+(a+k).toString(16).toUpperCase()+' (đọc '+h2(d[k])+', cần '+h2(img.mem[a+k])+').');
    prog(0.5+(p+1)/pages*0.5);
   }
  }
  await cmd([0x11,1,1]);                                              // thoát, chạy chương trình
  prog(1);
 }finally{
  try{await reader.cancel()}catch(e){}
  await pump;
  try{reader.releaseLock()}catch(e){}
  try{writer.releaseLock()}catch(e){}
  try{await port.close()}catch(e){}
 }
}

const G=typeof window!=='undefined'?window:globalThis;
G.MegaUploader={parseHex,upload};
if(typeof module!=='undefined'&&module.exports)module.exports=G.MegaUploader;
})();