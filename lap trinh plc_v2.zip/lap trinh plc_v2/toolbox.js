const tb=(n,c,t)=>({kind:'category',name:n,colour:c,contents:t.map(x=>({kind:'block',type:x}))});
const ws=Blockly.inject('ws',{toolbox:{kind:'categoryToolbox',contents:[
 tb('CASE',210,['jig_case','jig_once','jig_goto','jig_end']),
 tb('Thiết bị',160,['jig_out','jig_valve','jig_valve_go','jig_servo','jig_mgo','jig_mhome','jig_bldc','jig_bldc_go']),
 tb('LCD',160,['jig_lcd_text','jig_lcd_var','jig_lcd_clear']),
 tb('Input',210,['jig_in','jig_valve_at','jig_motor_is','jig_bldc_is','jig_timer_ge','jig_var_cmp','jig_trk_is','jig_trk_case','jig_and','jig_or','jig_not']),
 tb('Điều kiện',20,['jig_if','jig_wait','jig_after']),
 tb('Biến',290,['jig_set_var','jig_inc_var']),
 tb('Gọi CT con',330,['jig_start_trk']),
 tb('Lỗi',0,['jig_alarm'])]},
 trashcan:true,zoom:{controls:true,wheel:true,startScale:.9},grid:{spacing:20,length:2,colour:'#ccd',snap:true}});