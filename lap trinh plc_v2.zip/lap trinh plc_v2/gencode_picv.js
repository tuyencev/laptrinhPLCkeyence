/* gencode_pic.js
 * Bản port của gencode.js (PLC Keyence) sang CCS C cho PIC16F877A.
 * Giữ nguyên: các block jig_*, track/CASE, compile() -> {tr,ks,issues}, gen(r) -> chuỗi mã.
 * Thay lõi:  DM st/pc/tm/en  ->  trk_run[] / tk_state[] / tk_t[] / tk_entry[] + go()
 *            xung CR2005 0,1s -> Timer1 ISR 100ms (chỉ báo cờ)
 *
 * Giả định mô hình thiết bị (devices) phía PIC  (xem devCheck):
 *   {name, type:'in'  , f:{addr:'PIN_B1'}}
 *   {name, type:'out' , f:{addr:'PIN_D3' | '595:5'}}
 *   {name, type:'v52' , f:{addr:<out>, home:<in|PIN>, work:<in|PIN>}}      van 1 cuộn  (W = bật, H = tắt)
 *   {name, type:'v53' , f:{a1:<out>, a2:<out>, home:.., work:..}}          van 2 cuộn  (W = a2 bật, H = a1 bật; khớp dashboard: #1 lùi, #2 tới)
 *   {name, type:'var' , f:{addr:'ten_bien'}}                               biến int16
 * Cần sẵn các biến toàn cục như bên PLC: devices, tabs, ws, act, $, Blockly.
 * KHÔNG nạp chung với gencode.js (trùng tên ex/stm/one/compile/gen/devCheck/outsOf/syncCur).
 */

(function(){
// ───────────────────────── tiện ích ─────────────────────────
const NEGC = {'==':'!=','!=':'==','<':'>=','>':'<=','<=':'>','>=':'<'};
const OPC  = o => o==='=' ? '==' : o==='<>' ? '!=' : o;
const Tk   = s => Math.min(65535, Math.round(+s*10));          // giây -> tick 100ms
const pDev = n => devices.find(d=>d.name===n);
const val$ = id => (typeof $==='function' && $(id) && $(id).value) || '';
const ascii = s => String(s).replace(/[^\x20-\x7E]/g,'?');
const ind  = a => a.map(x=>'    '+x);
const emp  = a => a.length ? a : ['/* (trong) */'];
const IF   = (cond,th,el) => [`if (${cond}) {`,...ind(emp(th)),...(el&&el.length?['} else {',...ind(el)]:[]),'}'];

const PIN_RE = /^PIN_[A-E][0-7]$/i;
const RESERVED_PIN_RE = /^PIN_C[3-7]$/i;
const OUT_RE = /^(PIN_[A-E][0-7]|595:\d{1,2}|\d{1,2})$/i;

// tín hiệu vào (tên input đã khai báo hoặc chân PIN_xx) -> biểu thức C 0/1
function pSig(a){
  a=String(a||'').trim(); const d=devices.find(x=>x.type==='in'&&x.name.toUpperCase()===a.toUpperCase());
  if(d)return d.name;
  if(PIN_RE.test(a)&&!RESERVED_PIN_RE.test(a))return `input(${a})`;
  return null;
}
// ghi 1 ngõ ra (595:idx | số | PIN_xx) -> câu lệnh C
function pWr(a,v){
  a=String(a||'').trim(); let m;
  if((m=/^595:(\d+)$/.exec(a))||(m=/^(\d+)$/.exec(a)))return `data595[${m[1]}] = ${v};`;
  if(/^PIN_/i.test(a))return v?`output_high(${a});`:`output_low(${a});`;
  return null;
}
// khoá địa chỉ chuẩn hoá dùng trong gói trạng thái gửi PC: 'PIN_B1' hoặc '595:3' (null nếu không hợp lệ)
function inKey(a){
  a=String(a||'').trim(); const d=devices.find(x=>x.type==='in'&&x.name.toUpperCase()===a.toUpperCase());
  if(d)a=String(d.f.addr||'').trim();
  return PIN_RE.test(a)?a.toUpperCase():null;
}
function outKey(a){
  a=String(a||'').trim(); let m;
  if((m=/^595:(\d+)$/.exec(a))||(m=/^(\d+)$/.exec(a)))return +m[1]<24?'595:'+(+m[1]):null;
  return PIN_RE.test(a)?a.toUpperCase():null;
}
// hành động van: A = 'W' (làm việc) | 'H' (về home)
function pVl(d,A){
  const w=A==='W';
  if(d.type==='v52')return [pWr(d.f.addr,w?1:0)].filter(Boolean);
  if(d.type==='v53')return [pWr(d.f.a1,w?0:1),pWr(d.f.a2,w?1:0)].filter(Boolean);   // W: a2 bật / H: a1 bật
  return [];
}

// ───────────────────────── biểu thức điều kiện ─────────────────────────
function ex(b,neg,c){
 const bad=m=>{c.iss.push(['e',`Track ${c.t}: ${m}`]);return '0'};
 if(!b)return bad('có ô điều kiện bị trống.');
 const T=()=>{const k=+b.getFieldValue('TRK');c.refs.push([c.t,k,'Điều kiện']);return k};
 switch(b.type){
 case 'jig_in':{const d=pDev(b.getFieldValue('N'));if(!d||d.type!=='in')return bad('input chưa khai báo.');
  return `(${d.name} == ${(b.getFieldValue('LV')==='1')!==neg?1:0})`}
 case 'jig_valve_at':{const d=pDev(b.getFieldValue('N')),w=b.getFieldValue('P');if(!d)return bad('van chưa khai báo.');
  const a=d.f[w==='W'?'work':'home'],s=a&&pSig(a);if(!s)return bad(`van "${d.name}" chưa khai báo cảm biến ${w==='W'?'Work':'Home'}.`);
  return `(${s} == ${neg?0:1})`}
 case 'jig_var_cmp':{const d=pDev(b.getFieldValue('V'));if(!d||d.type!=='var')return bad('biến chưa khai báo.');
  let op=OPC(b.getFieldValue('OP'));if(neg)op=NEGC[op]||op;return `(${d.f.addr} ${op} ${b.getFieldValue('N')})`}
 case 'jig_timer_ge':return `(tk_t[${c.t}] ${neg?'<':'>='} ${Tk(b.getFieldValue('T'))})`;
 case 'jig_trk_is':{const k=T();return `(trk_run[${k}] ${neg?'!=':'=='} ${b.getFieldValue('M')})`}
 case 'jig_trk_case':{const k=T(),n=b.getFieldValue('N');
  return neg?`(trk_run[${k}] != 1 || tk_state[${k}] != ${n})`:`(trk_run[${k}] == 1 && tk_state[${k}] == ${n})`}
 case 'jig_motor_is':return bad('block motor chưa được hỗ trợ trên PIC (dùng khối stepper riêng).');
 case 'jig_not':return ex(b.getInputTargetBlock('A'),!neg,c);
 default:{const and=(b.type==='jig_and')!==neg;return '('+ex(b.getInputTargetBlock('A'),neg,c)+(and?' && ':' || ')+ex(b.getInputTargetBlock('B'),neg,c)+')'}}
}

// ───────────────────────── câu lệnh ─────────────────────────
function stm(b,c){let L=[];for(;b;b=b.getNextBlock())L=L.concat(one(b,c));return L}
function one(b,c){
 const t=c.t,nu=n=>+b.getFieldValue(n),cd=()=>ex(b.getInputTargetBlock('C'),false,c);
 const bad=m=>{c.iss.push(['e',`Track ${t}: ${m}`]);return []};
 const Fl=k=>['err_flag = 1;',`err_code = ${k};`,`err_trk = ${t};`];
 const tm=`tk_t[${t}]`;
 switch(b.type){
 case 'jig_out':{const d=pDev(b.getFieldValue('N'));if(!d||d.type!=='out')return bad('output chưa khai báo.');
  return [pWr(d.f.addr,b.getFieldValue('ST')==='1'?1:0)].filter(Boolean)}
 case 'jig_valve':{const d=pDev(b.getFieldValue('N'));if(!d)return bad('van chưa khai báo.');return pVl(d,b.getFieldValue('A'))}
 case 'jig_set_var':case 'jig_inc_var':{const d=pDev(b.getFieldValue('V'));if(!d||d.type!=='var')return bad('biến chưa khai báo.');
  const a=d.f.addr,n=nu('N');return [b.type==='jig_set_var'?`${a} = ${n};`:`${a} = ${a} + ${n};`]}
 case 'jig_after':return IF(`${tm} >= ${Tk(nu('T'))}`,stm(b.getInputTargetBlock('DO'),c));
 case 'jig_valve_go':{const d=pDev(b.getFieldValue('N')),a=b.getFieldValue('A');if(!d)return bad('van chưa khai báo.');
  const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),
        sn=pSig(d.f[a==='W'?'work':'home']);
  if(sn)return [...pVl(d,a),...IF(`${sn} == 1`,dO,IF(`${tm} >= ${T}`,to.length?to:Fl(10)))];
  c.iss.push(['w',`Track ${t}: van "${d.name}" chưa khai báo cảm biến ${a==='W'?'Work':'Home'}, dùng thời gian ${T/10} s thay cho cảm biến.`]);
  return [...pVl(d,a),...IF(`${tm} >= ${T}`,dO)]}
 case 'jig_goto':c.gotos.push([t,nu('N')]);return [`go(${t}, ${nu('N')});`];
 case 'jig_once':return IF(`tk_entry[${t}]`,[`tk_entry[${t}] = 0;`,...stm(b.getInputTargetBlock('BODY'),c)]);
 case 'jig_end':return [`trk_run[${t}] = 2;`];
 case 'jig_alarm':return Fl(nu('CODE'));
 case 'jig_if':return IF(cd(),stm(b.getInputTargetBlock('THEN'),c),stm(b.getInputTargetBlock('ELSE'),c));
 case 'jig_wait':{const T=Tk(nu('T'))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c);
  return IF(cd(),dO,IF(`${tm} >= ${T}`,to.length?to:Fl(10)))}
 case 'jig_start_trk':{const k=nu('TRK'),s=+b.getFieldValue('CASE')||0;c.refs.push([t,k,'Gọi',s]);return IF(`trk_run[${k}] != 1`,[`trk_start(${k}, ${s});`])}
 case 'jig_mhome':case 'jig_mhome2':case 'jig_mgo':case 'jig_servo':
  return bad('block motor/servo của PLC chưa được hỗ trợ trên PIC.');
 }
 return [];
}

// ───────────────────────── kiểm tra thiết bị ─────────────────────────
function outsOf(){
 const o=[];
 devices.forEach(d=>{const f=d.f||{};
  if(d.type==='out'||d.type==='v52')o.push(f.addr);
  if(d.type==='v53')o.push(f.a1,f.a2)});
 return o.filter(Boolean);
}
function devCheck(){
 const iss=[],seen={},addr={};
 devices.forEach(d=>{const f=d.f||{};
  const chk=(k,re,req,what)=>{const a=String(f[k]||'').trim();
   if(!a){if(req)iss.push(['e',`${d.name}: thiếu ${what||'địa chỉ'}.`]);return}
   if(!re.test(a))iss.push(['e',`${d.name}: "${a}" sai định dạng (${what||'địa chỉ'}).`]);
   else if(PIN_RE.test(a)&&RESERVED_PIN_RE.test(a))iss.push(['e',`${d.name}: chân ${a} đã dành cho 74HC595/UART trên PIC.`])};
  const sens=k=>{const a=String(f[k]||'').trim();if(a&&!pSig(a))iss.push(['e',`${d.name}: cảm biến ${k} "${a}" không phải input đã khai báo hoặc PIN_xx.`])};
  const used=k=>{const a=String(f[k]||'').trim().toUpperCase();if(!a)return;
   if(addr[a])iss.push(['w',`Ngõ ra ${a} khai báo cho cả "${addr[a]}" và "${d.name}".`]);addr[a]=d.name};
  if(!/^[A-Za-z_]\w*$/.test(d.name))iss.push(['e',`Tên thiết bị "${d.name}" không hợp lệ (chỉ chữ, số, gạch dưới, không bắt đầu bằng số).`]);
  if(seen[d.name])iss.push(['e',`Tên thiết bị "${d.name}" bị trùng.`]);seen[d.name]=1;
  switch(d.type){
   case 'in':chk('addr',PIN_RE,true,'chân PIN_xx');break;
   case 'out':chk('addr',OUT_RE,true,'ngõ ra (PIN_xx hoặc 595:n)');used('addr');break;
   case 'v52':chk('addr',OUT_RE,true,'ngõ ra van');used('addr');sens('home');sens('work');break;
   case 'v53':chk('a1',OUT_RE,true,'ngõ ra cuộn 1');chk('a2',OUT_RE,true,'ngõ ra cuộn 2');used('a1');used('a2');sens('home');sens('work');break;
   case 'var':chk('addr',/^[A-Za-z_]\w*$/,true,'tên biến C');break;
   default:iss.push(['e',`${d.name}: loại thiết bị "${d.type}" không hỗ trợ trên PIC.`])}
 });
 return iss;
}
function syncCur(){if(act>=0)tabs[act].state=Blockly.serialization.workspaces.save(ws)}

// ───────────────────────── compile: giữ nguyên logic bản PLC (bỏ phần motor) ─────────────────────────
function compile(){
 syncCur();
 const iss=devCheck(),dT=Math.min(65535,Math.round(parseFloat(val$('deft')||10)*10));
 {const sf=val$('safe').trim();if(sf&&!pSig(sf))iss.push(['e',`Ô an toàn "${sf}" phải là tên input đã khai báo hoặc PIN_xx (để trống nếu không dùng).`])}
 const c={iss,refs:[],gotos:[],t:0,dT},tr=[];
 tabs.forEach((tab,t)=>{c.t=t;const w=new Blockly.Workspace(),cs={};
  try{if(tab.state)Blockly.serialization.workspaces.load(tab.state,w);
   const tops=w.getTopBlocks(true),cases=tops.filter(b=>b.type==='jig_case');
   if(cases.length<tops.length)iss.push(['w',`${tab.name}: có khối nằm ngoài CASE, sẽ bị bỏ qua.`]);
   cases.forEach(b=>{const n=+b.getFieldValue('N');if(n in cs){iss.push(['e',`${tab.name}: CASE ${n} bị trùng.`]);return}
    if(b.getDescendants(false).filter(x=>x.type==='jig_once').length>1)
     iss.push(['e',`${tab.name}, CASE ${n}: chỉ được dùng 1 khối "Khi vào CASE" trong mỗi CASE (gộp các việc vào cùng một khối).`]);
    cs[n]={title:b.getFieldValue('T'),L:stm(b.getInputTargetBlock('BODY'),c)}})}finally{w.dispose()}
  if(!(0 in cs))iss.push(['e',`${tab.name}: cần có CASE 0 (điểm bắt đầu).`]);
  tr[t]=cs});
 if(!tabs.length)iss.push(['w','Chưa có track nào. Bấm "+ Track".']);
 else if(!tabs.some(x=>x.auto))iss.push(['e','Cần ít nhất 1 track tick "Tự chạy khi Start".']);
 if(new Set(tabs.map(x=>x.name)).size<tabs.length)iss.push(['w','Có tên track trùng nhau.']);
 for(const [t,k,w] of c.refs){
  if(k===t&&w==='Gọi')iss.push(['e',`Track ${t} tự gọi chính nó.`]);
  else if(!tabs[k])iss.push(['e',`Track ${t}: ${w} track ${k} nhưng track này không tồn tại.`]);}
 for(const [t,k,w,s] of c.refs)if(w==='Gọi'&&tabs[k]&&!(s in tr[k]))
  iss.push(['e',`Track ${t}: gọi track ${k} từ CASE ${s} nhưng track đích không có CASE ${s}.`]);
 for(const [t,n] of c.gotos)if(!(n in tr[t]))iss.push(['e',`${tabs[t].name}: chuyển sang CASE ${n} nhưng track không có CASE ${n}.`]);
 return {tr,ks:tr.map((_,i)=>i),issues:[...new Set(iss.map(JSON.stringify))].map(JSON.parse)};
}

// ───────────────────────── gen: sinh toàn bộ chương trình CCS C ─────────────────────────
function gen(r){
 const safeRaw=val$('safe').trim(),safe=pSig(safeRaw);   // chỉ nhận tên input hoặc PIN_xx, còn lại bỏ qua (compile đã báo lỗi)
 const U=r.ks,N=Math.max(U.length,1),L=[];
 const ins=devices.filter(d=>d.type==='in'),vars=devices.filter(d=>d.type==='var');
 // địa chỉ vào/ra PIC báo lên PC: khoá của các dòng IN/OUT trong gói trạng thái (dashboard khớp theo địa chỉ này)
 const IN_A=[],OUT_A=[],addU=(A,x)=>{if(x&&!A.includes(x))A.push(x)};
 devices.forEach(d=>{const f=d.f||{};
  if(d.type==='in')addU(IN_A,inKey(f.addr));
  if(d.type==='v52'||d.type==='v53'){addU(IN_A,inKey(f.home));addU(IN_A,inKey(f.work))}
  if(d.type==='out'||d.type==='v52')addU(OUT_A,outKey(f.addr));
  if(d.type==='v53'){addU(OUT_A,outKey(f.a1));addU(OUT_A,outKey(f.a2))}});
 addU(IN_A,inKey(safeRaw));
 const rdOut=a=>/^595:/.test(a)?`data595[${a.slice(4)}]`:`output_state(${a})`;

 L.push(`// Sinh tu Blockly - ${U.length} track (PIC16F877A, state-timer 100ms)`,
  '#include<main.h>','#use rs232(baud=115200, xmit=PIN_C6, rcv=PIN_C7, bits=8)','#include<string.h>','',
  `#define NTRK ${N}`,'');

 // --- thiết bị ---
 ins.forEach(d=>L.push(`#define ${d.name}  input(${d.f.addr})`));
 vars.forEach(d=>L.push(`int16 ${d.f.addr} = 0;`));
 L.push('');

 // --- 74HC595 (24 bit) ---
 L.push(String.raw`#define CLK595_H       output_high(PIN_c3)
#define CLK595_L       output_low(PIN_c3)
#define LATCH595_H     output_high(PIN_c5)
#define LATCH595_L     output_low(PIN_c5)
#define DATA595_H      output_high(PIN_c4)
#define DATA595_L      output_low(PIN_c4)
unsigned int1 data595[24];

void send_595(void)
{
    signed int8 i;
    for (i = 23; i > -1; i--) { if (data595[i]) DATA595_H; else DATA595_L; CLK595_L; CLK595_H; }
    LATCH595_L; LATCH595_H;
}

void init_595(void)
{
    int8 j;
    for (j = 0; j < 24; j++) data595[j] = 0;
    send_595();
}
`);

 // --- ghi ngõ ra trực tiếp từ PC (thủ công): PIN_xx=v ; ngõ ra 595 dùng lệnh dNN=v ---
 L.push('// ghi ngo ra truc tiep tu PC: ten_chan=gia_tri (tra 1 neu nhan ra chan)','int1 set_pin_cmd(char *name, int16 v)','{',
  ...OUT_A.filter(a=>!/^595:/.test(a)).map(a=>`    if (strcmp(name, "${a}") == 0) { if (v) output_high(${a}); else output_low(${a}); return 1; }`),
  '    return 0;','}','');

 // --- lõi state-timer ---
 L.push(String.raw`// ---- loi track/state-timer (don vi 100ms) ----
#define TK_TICK_PRELOAD 3036   // 100ms: 20MHz, Timer1 DIV_BY_8 (65536-62500)
int8  trk_run[NTRK];           // 0 dung, 1 chay, 2 xong, 3 loi
int16 tk_state[NTRK];          // CASE hien tai cua tung track
int16 tk_t[NTRK];              // thoi gian trong CASE, don vi 100ms
int8  tk_entry[NTRK];          // =1 o vong dau tien cua moi CASE
int1  err_flag = 0;
int8  err_code = 0;
int8  err_trk  = 0;
int8  run_cmd  = 0;            // 1 chay, 2 dung, 3 xoa loi (tu PC)
int1  giaotiep = 0;
int1  manual   = 0;
int16 time_send_data = 0;
int1  send_now = 0;            // =1: vua co thay doi -> gui goi trang thai ngay cho PC
int8  send_gap = 0;            // so tick con lai truoc khi duoc gui goi su kien tiep theo
#define TK_SEND_PERIOD 2       // goi dinh ky: 2 tick = 200ms
#define TK_SEND_GAP    2       // khoang cach toi thieu giua 2 goi: 2 tick (100..200ms), chong nhieu lam tran UART
volatile int1 tick_flag = 0;

#INT_TIMER1
void timer1_isr(void)
{
    set_timer1(get_timer1() + TK_TICK_PRELOAD);   // bu do tre vao ISR
    tick_flag = 1;                                // ISR chi bao co
}

// Chuyen CASE cua 1 track: reset thoi gian o DUY NHAT cho nay
void go(int8 id, int16 s)
{
    tk_state[id] = s;
    tk_t[id]     = 0;
    tk_entry[id] = 1;
    send_now     = 1;            // doi CASE: bao PC ngay
}

void trk_start(int8 k, int16 start_case)
{
    trk_run[k] = 1;
   go(k, start_case);
}

#define RX_BUF_LEN 32
char rx_buffer[RX_BUF_LEN];
char cmd_buffer[RX_BUF_LEN];
int1 rx_ready = 0;

#INT_RDA
void serial_isr(void)
{
    static int8 idx = 0;
    char c = getc();
    if (c == '\n' || c == '\r') {
        if (idx > 0) { rx_buffer[idx] = '\0'; rx_ready = 1; idx = 0; }
    } else if (idx < (RX_BUF_LEN - 1)) {
        rx_buffer[idx++] = c;
    }
}

int16 my_atoi(char *s)
{
    int16 v = 0;
    while (*s >= '0' && *s <= '9') { v = v * 10 + (*s - '0'); s++; }
    return v;
}

// Lenh tu PC: r chay | x dung | c xoa loi | g bat gui trang thai | d tat | m thu cong | a tu dong | dNN=v ghi ngo ra 595 | PIN_xx=v ghi ngo ra truc tiep
void process_cmd(char *cmd)
{
    char *eq = strchr(cmd, '=');
    if (eq) {
        int16 idx, v;
        *eq = '\0';
        idx = (cmd[0] == 'd' || cmd[0] == 'D') ? my_atoi(cmd + 1) : 255;
        v   = my_atoi(eq + 1);
        if (idx < 24) { data595[idx] = (v != 0); printf("OK %s=%lu\r\n", cmd, v); }
        else if (set_pin_cmd(cmd, v)) printf("OK %s=%lu\r\n", cmd, v);
        else printf("ERR Unknown pin %s\r\n", cmd);
    }
    else if (cmd[0] == 'r') run_cmd = 1;
    else if (cmd[0] == 'x') run_cmd = 2;
    else if (cmd[0] == 'c') run_cmd = 3;
    else if (cmd[0] == 'g') { giaotiep = 1; send_now = 1; }
    else if (cmd[0] == 'd') giaotiep = 0;
    else if (cmd[0] == 'm') { manual = 1; printf("MANUAL MODE\r\n"); }
    else if (cmd[0] == 'a') { manual = 0; printf("AUTO MODE\r\n"); }
}
`);

 // --- in trạng thái cho dashboard ---
 L.push('void printAllStates(void)','{','    int8 i;','    printf("BEGIN\\r\\n");');
 vars.forEach(d=>L.push(`    printf("${d.f.addr} = %lu\\r\\n", (int16)(${d.f.addr}));`));
 L.push('   for (i = 0; i < NTRK; i++)printf("TRK %u run=%u case=%u t=%lu\r\n", (unsigned int)i, (unsigned int)trk_run[i], (unsigned int)tk_state[i], (unsigned long)tk_t[i]);',
  '    printf("ERR %u code=%u trk=%u\\r\\n", err_flag, err_code, err_trk);','    printf("SYS man=%u\\r\\n", manual);');
 IN_A.forEach(a=>L.push(`    printf("IN ${a}=%u\\r\\n", input(${a}));`));
 OUT_A.forEach(a=>L.push(`    printf("OUT ${a}=%u\\r\\n", ${rdOut(a)});`));
 L.push('    printf("END\\r\\n");','}','');

 // --- phat hien thay doi de bao PC ngay (send_now) ---
 const IO=[...IN_A.map(a=>`input(${a})`),...OUT_A.map(rdOut)];
 L.push(`#define NIO ${Math.max(IO.length,1)}`,'int1  io_prev[NIO];','int8  prev_run[NTRK];','int1  prev_err = 0;','int1  prev_man = 0;','',
  '// doi vao/ra, doi trang thai track, loi, thu cong -> send_now = 1','void detect_changes(void)','{','    int8 k;','    int1 v;',
  ...IO.flatMap((e,i)=>[`    v = ${e};`,`    if (v != io_prev[${i}]) { io_prev[${i}] = v; send_now = 1; }`]),
  '    for (k = 0; k < NTRK; k++) if (trk_run[k] != prev_run[k]) { prev_run[k] = trk_run[k]; send_now = 1; }',
  '    if (err_flag != prev_err) { prev_err = err_flag; send_now = 1; }',
  '    if (manual != prev_man)   { prev_man = manual;   send_now = 1; }','}','');

 // --- từng track ---
 for(const t of U){
  L.push(`// --- TRACK ${t}: ${ascii(tabs[t].name||'')} ---`,`void trk_${t}(void)`,'{',`    switch (tk_state[${t}])`,'    {');
  Object.keys(r.tr[t]).map(Number).sort((a,b)=>a-b).forEach(n=>{
   L.push(`    case ${n}:`,...ind(ind(emp(r.tr[t][n].L))),'        break;','');});
  L.push('    default:','        err_flag = 1;','        err_code = 99;',`        err_trk = ${t};`,'        break;','    }','}','');
 }

 // --- vòng quét chính ---
 const forAll=body=>['for (k = 0; k < NTRK; k++) { '+body+' }'];
 L.push('void jig_scan(void)','{','    int8 k;','    int1 idle;','    switch (run_cmd)','    {','    case 1:',
  '        idle = 1;','        for (k = 0; k < NTRK; k++) if (trk_run[k] == 1) idle = 0;','        if (idle) {',
  '            err_flag = 0; err_code = 0; err_trk = 0; manual = 0;');
 U.forEach(t=>L.push(tabs[t].auto?`            trk_start(${t}, 0);`:`            trk_run[${t}] = 0; go(${t}, 0);`));
 L.push('        }','        break;','    case 2:',...ind(ind(forAll('trk_run[k] = 0;'))),'        break;',
  '    case 3:','        err_flag = 0; err_code = 0; err_trk = 0;',...ind(ind(forAll('trk_run[k] = 0;'))),'        break;','    }','    run_cmd = 0;','');
 if(safe)L.push(`    // an toan: ${ascii(safeRaw)} = 0 la loi`,`    if ((${safe}) == 0) { err_flag = 1; err_code = 1; err_trk = 0; }`,'');
 U.forEach(t=>L.push(`    if (err_flag == 0 && trk_run[${t}] == 1) trk_${t}();`));
 L.push('','    if (err_flag) {',...ind(forAll('trk_run[k] = 3;')),'    }','');
 const o=outsOf();
 if(o.length){
  L.push('    idle = 1;','    for (k = 0; k < NTRK; k++) if (trk_run[k] != 0) idle = 0;',
   '    // loi hoac dung: tat output','    if (err_flag || (idle && manual == 0)) {',...ind(o.map(a=>pWr(a,0)).filter(Boolean)),'    }');
 }
 L.push('}','');

 // --- main ---
 L.push('void main()','{','    int8 k;','    init_595();',
  '    output_high(PIN_D3); output_high(PIN_C5);','    delay_ms(1000);','    output_low(PIN_D3);  output_low(PIN_C5);',
  '    for (k = 0; k < NTRK; k++) { trk_run[k] = 0; tk_state[k] = 0; tk_t[k] = 0; tk_entry[k] = 1; }',
  '    setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);','    set_timer1(TK_TICK_PRELOAD);',
  '    enable_interrupts(INT_TIMER1);','    enable_interrupts(INT_RDA);','    enable_interrupts(GLOBAL);','',
  '    while (TRUE)','    {','        if (tick_flag) {','            tick_flag = 0;',
  '            for (k = 0; k < NTRK; k++) { if (tk_t[k] < 65535) tk_t[k]++; }',
  '            if (giaotiep) time_send_data++;','            if (send_gap) send_gap--;','        }',
  '        if (rx_ready) {','            disable_interrupts(INT_RDA);','            strcpy(cmd_buffer, rx_buffer);','            rx_ready = 0;',
  '            enable_interrupts(INT_RDA);','            process_cmd(cmd_buffer);','        }',
  '        jig_scan();','        send_595();','        detect_changes();',
  '        if (giaotiep && ((send_now && send_gap == 0) || time_send_data >= TK_SEND_PERIOD)) {',
  '            printAllStates();','            send_now = 0;','            time_send_data = 0;','            send_gap = TK_SEND_GAP;','        }','    }','}');
 return L.join('\n');
}

window.compile=compile; window.gen=gen; window.devCheck=devCheck; window.outsOf=outsOf; window.syncCur=syncCur;
window.V=t=>({st:t,pc:t,tm:t,en:t,ms:t});   // app.js (render) gọi V(t) để hiện nhãn; trên PIC không còn là địa chỉ DM
window.normM=d=>d;   // app.js gọi normM cho motor cũ; PIC không dùng motor (devCheck sẽ báo lỗi loại thiết bị)
})();
