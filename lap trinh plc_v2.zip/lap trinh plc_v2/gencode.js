(()=>{
const V=t=>({st:2000+10*t,pc:2001+10*t,tm:2003+10*t,en:2004+10*t,ms:2005+10*t});
function ex(b,neg,c){
 const bad=m=>{c.iss.push(['e',`Track ${c.t}: ${m}`]);return 'R000 = ON'};
 if(!b)return bad('có ô điều kiện bị trống.');
 const T=()=>{const k=+b.getFieldValue('TRK');c.refs.push([c.t,k,'Điều kiện']);return k};
 switch(b.type){
 case 'jig_in':{const a=pinAddr('i',b.getFieldValue('N'));if(!a)return bad('input chưa khai báo.');return `${a} = ${(b.getFieldValue('LV')==='1')!==neg?'ON':'OFF'}`}
 case 'jig_valve_at':{const d=devOf(b.getFieldValue('N')),w=b.getFieldValue('P');if(!d)return bad('van chưa khai báo.');
  const a=d.f[w==='W'?'work':'home'];if(!a)return bad(`van "${d.name}" chưa khai báo cảm biến ${w==='W'?'Work':'Home'}.`);return `${a} = ${neg?'OFF':'ON'}`}
 case 'jig_var_cmp':{const d=devOf(b.getFieldValue('V'));if(!d)return bad('biến chưa khai báo.');let op=b.getFieldValue('OP');if(neg)op=NEG[op];return `${d.f.addr} ${op} ${b.getFieldValue('N')}`}
 case 'jig_timer_ge':return `DM${V(c.t).tm} ${neg?'<':'>='} ${Math.min(65535,Math.round(+b.getFieldValue('T')*10))}`;
 case 'jig_trk_is':{const k=T();return `DM${V(k).st} ${neg?'<>':'='} ${b.getFieldValue('M')}`}
 case 'jig_trk_case':{const k=T(),n=b.getFieldValue('N'),v=V(k);return neg?`(DM${v.st} <> 1 OR DM${v.pc} <> ${n})`:`(DM${v.st} = 1 AND DM${v.pc} = ${n})`}
 case 'jig_motor_is':{const d=devOf(b.getFieldValue('N')),p=b.getFieldValue('P');if(!d)return bad('motor chưa khai báo.');const a=d.f[p];if(!a)return bad(`motor "${d.name}" chưa khai báo chân ${TAG[p]}.`);return `${a} = ${neg?'OFF':'ON'}`}
 case 'jig_not':return ex(b.getInputTargetBlock('A'),!neg,c);
 default:{const and=(b.type==='jig_and')!==neg;return '('+ex(b.getInputTargetBlock('A'),neg,c)+(and?' AND ':' OR ')+ex(b.getInputTargetBlock('B'),neg,c)+')'}}
}
function stm(b,c){let L=[];for(;b;b=b.getNextBlock())L=L.concat(one(b,c));return L}
function one(b,c){
 const t=c.t,v=V(t),ind=a=>a.map(x=>'  '+x),nu=n=>+b.getFieldValue(n),cd=()=>ex(b.getInputTargetBlock('C'),false,c);
 const bad=m=>{c.iss.push(['e',`Track ${t}: ${m}`]);return []};
 const Fl=k=>['MR110 = ON',`DM1993 = ${k}`,`DM1998 = ${t}`],emp=a=>a.length?a:["' (trong)"];
 switch(b.type){
 case 'jig_out':{const a=pinAddr('o',b.getFieldValue('N'));if(!a)return bad('output chưa khai báo.');return [`${a} = ${b.getFieldValue('ST')==='1'?'ON':'OFF'}`]}
 case 'jig_valve':{const d=devOf(b.getFieldValue('N'));if(!d)return bad('van chưa khai báo.');return vl(d,b.getFieldValue('A'))}
 case 'jig_set_var':case 'jig_inc_var':{const d=devOf(b.getFieldValue('V'));if(!d)return bad('biến chưa khai báo.');
  const a=d.f.addr,n=nu('N');return [b.type==='jig_set_var'?`${a} = ${n}`:`${a} = ${a} + ${n}`]}
 case 'jig_after':return [`IF DM${v.tm} >= ${Math.min(65535,Math.round(nu('T')*10))} THEN`,...ind(emp(stm(b.getInputTargetBlock('DO'),c))),'END IF'];
 case 'jig_servo':{const d=devOf(b.getFieldValue('N'));if(!d)return bad('motor chưa khai báo.');if(!d.f.servo)return bad(`motor "${d.name}" chưa khai báo chân Servo ON.`);return [`${d.f.servo} = ${b.getFieldValue('ST')==='1'?'ON':'OFF'}`]}
 case 'jig_valve_go':{const d=devOf(b.getFieldValue('N')),a=b.getFieldValue('A');if(!d)return bad('van chưa khai báo.');
  const T=Math.min(65535,Math.round(nu('T')*10))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),sn=d.f[a==='W'?'work':'home'];
  if(sn)return [...vl(d,a),`IF ${sn} = ON THEN`,...ind(emp(dO)),'ELSE',`  IF DM${v.tm} >= ${T} THEN`,...ind(ind(to.length?to:Fl(10))),'  END IF','END IF'];
  c.iss.push(['w',`Track ${t}: van "${d.name}" chưa khai báo cảm biến ${a==='W'?'Work':'Home'}, dùng thời gian ${T/10} s thay cho cảm biến.`]);
  return [...vl(d,a),`IF DM${v.tm} >= ${T} THEN`,...ind(emp(dO)),'END IF']}
 case 'jig_goto':c.gotos.push([t,nu('N')]);return [`DM${v.pc} = ${nu('N')}`,`DM${v.tm} = 0`,`DM${v.en} = 0`,...axs().map(a=>`DM${v.ms+a} = 0`)];
 case 'jig_mhome':{const d=devOf(b.getFieldValue('N'));if(!d||d.type!=='motor')return bad('motor chưa khai báo.');const a=+d.axis;if(!(a>=1&&a<=4))return bad(`motor "${d.name}" chưa có số trục hợp lệ.`);
  const T=Math.min(65535,Math.round(nu('T')*10))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),ms=`DM${v.ms+a}`,sp=n=>x=>' '.repeat(n)+x;
  if(!(d.orgp||'').trim())c.iss.push(['w',`Track ${t}: motor "${d.name}" chưa nhập thông số về gốc (sẽ dùng giá trị cài trong KV STUDIO).`]);
  return [`IF ${ms} = 0 THEN`,`  ${ms} = 1`,`  ORG(0, ${a})`,'ELSE',`  IF CR${crS(a,2)} = ON THEN`,...Fl(30+a).map(sp(4)),'  ELSE',`    IF ${ms} = 1 AND CR${crS(a,4)} = ON THEN`,`      ${ms} = 2`,'    END IF',`    IF ${ms} = 2 AND CR${crS(a,5)} = ON AND CR${crS(a,4)} = OFF THEN`,...emp(dO).map(sp(6)),'    ELSE',`      IF DM${v.tm} >= ${T} THEN`,...(to.length?to:Fl(50+a)).map(sp(8)),'      END IF','    END IF','  END IF','END IF']}
 case 'jig_mhome2':{const d=devOf(b.getFieldValue('N'));if(!d||d.type!=='motor')return bad('motor chưa khai báo.');const a=+d.axis;if(!(a>=1&&a<=4))return bad(`motor "${d.name}" chưa có số trục hợp lệ.`);
  const T=Math.min(65535,Math.round(nu('T')*10))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),ms=`DM${v.ms+a}`,sp=n=>x=>' '.repeat(n)+x;
  return [`IF ${ms} = 0 THEN`,`  ${ms} = 1`,`  HOME(0, ${a})`,'ELSE',`  IF CR${crS(a,2)} = ON THEN`,...Fl(30+a).map(sp(4)),'  ELSE',`    IF ${ms} = 1 THEN`,`      IF CR${crS(a,0)} = ON OR DM${v.tm} >= 5 THEN`,`        ${ms} = 2`,'      END IF','    END IF',`    IF ${ms} = 2 AND CR${crS(a,0)} = OFF THEN`,...emp(dO).map(sp(6)),'    ELSE',`      IF DM${v.tm} >= ${T} THEN`,...(to.length?to:Fl(60+a)).map(sp(8)),'      END IF','    END IF','  END IF','END IF']}
 case 'jig_once':return [`IF DM${v.en} = 0 THEN`,`  DM${v.en} = 1`,...ind(emp(stm(b.getInputTargetBlock('BODY'),c))),'END IF'];
 case 'jig_mgo':{const d=devOf(b.getFieldValue('N')),p=nu('P');if(!d||d.type!=='motor')return bad('motor chưa khai báo.');const a=+d.axis;if(!(a>=1&&a<=4))return bad(`motor "${d.name}" chưa có số trục hợp lệ.`);
  const T=Math.min(65535,Math.round(nu('T')*10))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c),ms=`DM${v.ms+a}`;
  if(!pts(d).r[p])c.iss.push(['w',`Track ${t}: motor "${d.name}" chưa có điểm ${p} trong bảng điểm (sẽ dùng giá trị cài trong KV STUDIO).`]);
  const sp=n=>x=>' '.repeat(n)+x;
  return [`IF ${ms} = 0 THEN`,`  ${ms} = 1`,`  PSTRT(0, ${a}, ${p})`,'ELSE',`  IF CR${crS(a,2)} = ON THEN`,...Fl(30+a).map(sp(4)),'  ELSE',`    IF CR${crS(a,1)} = ON AND CR${crS(a,0)} = OFF AND CM${cmA(a)+35} = ${p} THEN`,...emp(dO).map(sp(6)),'    ELSE',`      IF DM${v.tm} >= ${T} THEN`,...(to.length?to:Fl(40+a)).map(sp(8)),'      END IF','    END IF','  END IF','END IF']}
 case 'jig_end':return [`DM${v.st} = 2`];
 case 'jig_alarm':return Fl(nu('CODE'));
 case 'jig_if':{const th=stm(b.getInputTargetBlock('THEN'),c),el=stm(b.getInputTargetBlock('ELSE'),c);
  return [`IF ${cd()} THEN`,...ind(emp(th)),...(el.length?['ELSE',...ind(el)]:[]),'END IF']}
 case 'jig_wait':{const T=Math.min(65535,Math.round(nu('T')*10))||c.dT,dO=stm(b.getInputTargetBlock('DO'),c),to=stm(b.getInputTargetBlock('TO'),c);
  return [`IF ${cd()} THEN`,...ind(emp(dO)),'ELSE',`  IF DM${v.tm} >= ${T} THEN`,...ind(ind(to.length?to:Fl(10))),'  END IF','END IF']}
 case 'jig_start_trk':{const k=nu('TRK'),s=+b.getFieldValue('CASE')||0,w=V(k);c.refs.push([t,k,'Gọi',s]);
  return [`IF DM${w.st} <> 1 THEN`,`  DM${w.st} = 1`,`  DM${w.pc} = ${s}`,`  DM${w.tm} = 0`,`  DM${w.en} = 0`,...axs().map(a=>`  DM${w.ms+a} = 0`),'END IF']}
 }
 return [];
}
function pts(d){const r={},er=[],K=['tg','ac','de','sp'];(d.rows||[]).forEach((o,i)=>{const e={};K.forEach(k=>{const v=String((o&&o[k])??'').trim();if(v==='')return;if(!/^-?\d+$/.test(v))er.push(`${d.name}: điểm ${i+1}, ô ${k} phải là số nguyên thập phân ("${v}")`);else e[k]=v});if(Object.keys(e).length)r[i+1]=e});return {r,er}}


function normM(d){const o={axis:'1',orgp:'',...d};if(!Array.isArray(o.rows)||!o.rows.length){o.rows=[{tg:'20'}];(d.pts||'').split('\n').forEach(l=>{const v=l.trim().split(/\s+/).map(Number);if(v.length===7&&v[0]>=1&&v[0]<=20){while(o.rows.length<v[0])o.rows.push({});o.rows[v[0]-1]={c6:String(v[1]),tg:String(v[2]),sp:String(v[3]),ac:String(v[4]),de:String(v[5])}}})}else if(o.rows.every(r=>!r||Object.values(r).every(v=>String(v??'').trim()==='')))o.rows=[{tg:'20'}];delete o.pts;return o}
const cmP=(a,p)=>8000+200*(a-1)+10*(p-1),cmA=a=>8800+40*(a-1),crC=(a,k)=>8000+100*(a-1)+k,crS=(a,k)=>8400+100*(a-1)+k;
const motors=()=>devices.filter(d=>d.type==='motor'&&/^[1-4]$/.test(String(d.axis||'')));
const axs=()=>[...new Set(motors().map(d=>+d.axis))];
const ascii=s=>String(s).replace(/[^\x20-\x7E]/g,'?');
function motorInit(){const L=[];motors().forEach(d=>{const a=+d.axis,P=pts(d).r,k=Object.keys(P),o=(d.orgp||'').trim().split(/\s+/).map(Number),hO=o.length>=4&&o.length<=5&&o.every(Number.isFinite);if(!k.length&&!hO)return;
 L.push(`IF CR${crS(a,0)} = OFF THEN`);
 if(hO){const b=cmA(a);L.push(`  CM${b+9} = ${o[0]}`,`  CM${b+10} = ${o[1]}`,`  CM${b+11} = ${o[2]}`,`  CM${b+12}.L = ${o[3]}`);if(o.length===5)L.push(`  CM${b+14} = ${o[4]}`)}
 k.forEach(p=>{const e=P[p],b=cmP(a,+p);if('tg' in e)L.push(`  CM${b}.L = ${e.tg}`);if('ac' in e)L.push(`  CM${b+2} = ${e.ac}`);if('de' in e)L.push(`  CM${b+3} = ${e.de}`);if('sp' in e)L.push(`  CM${b+4}.L = ${e.sp}`)});L.push('END IF')});return L}
function motorScan(){const L=[];motors().forEach(d=>{const a=+d.axis;L.push(`' --- Motor ${ascii(d.name)} (truc ${a}) ---`);
 if(d.f.lcw)L.push(`CR${crC(a,12)} = ${d.f.lcw}`);if(d.f.lccw)L.push(`CR${crC(a,13)} = ${d.f.lccw}`);
 const cK=1969+a,pK=1973+a,sK=1977+a,jK=1982+2*(a-1),jS=jK+1,pulse=d.f.cw,dir=d.f.ccw,
  limitStops=[d.f.lcw?`(CR${crC(a,12)} = ON AND (DM${jS} = 1 OR DM${jS} = 3 OR DM${jS} = 4))`:null,
   d.f.lccw?`(CR${crC(a,13)} = ON AND (DM${jS} = 2 OR DM${jS} = 5 OR DM${jS} = 6))`:null].filter(Boolean);
 if(pulse&&dir){
  L.push(`' Jog buoc co dau: DM${jK}; trang thai xung: DM${jS}`,
   `IF MR113 = OFF OR MR110 = ON${d.f.servo?` OR ${d.f.servo} = OFF`:''} OR DM${cK} <> 0${limitStops.length?' OR '+limitStops.join(' OR '):''} THEN`,
   `  ${pulse} = OFF`,`  ${dir} = OFF`,`  DM${jK} = 0`,`  DM${jS} = 0`,
   'ELSE',
   `  SELECT CASE DM${jS}`,
   '  CASE 0',`    ${pulse} = OFF`,`    ${dir} = OFF`,
   `  CASE 1`,`    IF CR${crS(a,0)} = ON THEN`,`      DM${jK} = 0`,`      DM${jS} = 0`,'    ELSE',
   `      ${pulse} = OFF`,`      ${dir} = OFF`,`      DM${jS} = 3`,'    END IF',
   `  CASE 2`,`    IF CR${crS(a,0)} = ON THEN`,`      DM${jK} = 0`,`      DM${jS} = 0`,'    ELSE',
   `      ${pulse} = OFF`,`      ${dir} = ON`,`      DM${jS} = 5`,'    END IF',
   `  CASE 3`,`    ${pulse} = ON`,`    ${dir} = OFF`,`    DM${jS} = 4`,
   `  CASE 4`,`    ${pulse} = OFF`,`    ${dir} = OFF`,`    DM${jK} = DM${jK} - 1`,
   `    IF DM${jK} <= 0 THEN`,`      DM${jK} = 0`,`      DM${jS} = 0`,'    ELSE',`      DM${jS} = 3`,'    END IF',
   `  CASE 5`,`    ${pulse} = ON`,`    ${dir} = ON`,`    DM${jS} = 6`,
   `  CASE 6`,`    ${pulse} = OFF`,`    ${dir} = ON`,`    DM${jK} = DM${jK} - 1`,
   `    IF DM${jK} <= 0 THEN`,`      DM${jK} = 0`,`      DM${jS} = 0`,`      ${dir} = OFF`,'    ELSE',`      DM${jS} = 5`,'    END IF',
   '  CASE ELSE',`    ${pulse} = OFF`,`    ${dir} = OFF`,`    DM${jK} = 0`,`    DM${jS} = 0`,
   '  END SELECT','END IF')}
 L.push(`IF MR110 = ON OR (MR112 = ON AND MR113 = OFF) OR (MR113 = ON AND DM${cK} = 4) THEN`,`  CR${crC(a,1)} = ON`,'ELSE',`  CR${crC(a,1)} = OFF`,'END IF');
 L.push(`' Thu cong tu dashboard: DM${cK} lenh (1 toi diem DM${pK}, 2 ORG, 3 HOME, 4 dung), DM${sK} da nhan lenh`,'IF MR113 = OFF OR MR110 = ON THEN',`  DM${cK} = 0`,`  DM${sK} = 0`,'ELSE',`  IF DM${cK} = 0 THEN`,`    DM${sK} = 0`,'  ELSE',`    IF DM${sK} = 0 AND DM${cK} <> 4 AND DM${jK} = 0 AND DM${jS} = 0 THEN`,`      DM${sK} = 1`);
 Object.keys(pts(d).r).map(Number).sort((x,y)=>x-y).forEach(q=>L.push(`      IF DM${cK} = 1 AND DM${pK} = ${q} THEN`,`        PSTRT(0, ${a}, ${q})`,'      END IF'));
 L.push(`      IF DM${cK} = 2 THEN`,`        ORG(0, ${a})`,'      END IF',`      IF DM${cK} = 3 THEN`,`        HOME(0, ${a})`,'      END IF','    END IF','  END IF','END IF')});return L}
function devCheck(){
 const iss=[],seen={},addr={};
 devices.forEach(d=>{
  if(!/^[A-Za-z_]\w*$/.test(d.name))iss.push(['e',`Tên thiết bị "${d.name}" không hợp lệ (chỉ chữ, số, gạch dưới, không bắt đầu bằng số).`]);
  if(seen[d.name])iss.push(['e',`Tên thiết bị "${d.name}" bị trùng.`]);seen[d.name]=1;if(d.type==='motor'){if(!/^[1-4]$/.test(String(d.axis||'')))iss.push(['e',`${d.name}: số trục phải từ 1 đến 4.`]);if(!d.f.cw||!d.f.ccw)iss.push(['e',`${d.name}: cần khai báo chân xung CW và chiều CCW để dùng jog xung.`]);pts(d).er.forEach(e=>iss.push(['e',e]));if((d.orgp||'').trim()&&!/^(-?\d+\s+){3,4}-?\d+$/.test(d.orgp.trim()))iss.push(['e',`${d.name}: thông số về gốc cần 4 số (tốc độ bắt đầu, gia tốc, giảm tốc, tốc độ), số thứ 5 là giá trị CM8814 (tùy chọn, bỏ trống nếu đã cài trong KV STUDIO).`])}
  DT[d.type].f.forEach(([k,,,x])=>{const a=d.f[k]||'';
   if(!a){if(REQ[d.type].includes(k))iss.push(['e',`${d.name}: thiếu địa chỉ.`]);return}
   if(!(d.type==='var'?RD:RA).test(a))iss.push(['e',`${d.name}: địa chỉ "${a}" sai định dạng.`]);
   if(d.type==='var'&&/^DM(197\d|198\d|199\d|20\d\d|21[0-4]\d)$/i.test(a))iss.push(['w',`${d.name}: ${a} nằm trong vùng DM1970-DM2149 dành cho hệ thống.`]);
   if(x==='o'||x==='p'){if(addr[a])iss.push(['w',`Chân ${a} khai báo cho cả "${addr[a]}" và "${d.name}".`]);addr[a]=d.name;if(x==='o'&&/^R50[01]$/i.test(a))iss.push(['w',`${d.name}: ${a} là ngõ ra xung CW/CCW của trục 1 theo sơ đồ Keyence.`])}})});
 return iss;
}
function syncCur(){if(act>=0)tabs[act].state=Blockly.serialization.workspaces.save(ws)}
function compile(){
 syncCur();
 const iss=devCheck(),dT=Math.min(65535,Math.round(parseFloat($('deft').value||10)*10));
 const c={iss,refs:[],gotos:[],t:0,dT},tr=[];
 tabs.forEach((tab,t)=>{c.t=t;const w=new Blockly.Workspace(),cs={};
  try{if(tab.state)Blockly.serialization.workspaces.load(tab.state,w);
   const tops=w.getTopBlocks(true),cases=tops.filter(b=>b.type==='jig_case');
   if(cases.length<tops.length)iss.push(['w',`${tab.name}: có khối nằm ngoài CASE, sẽ bị bỏ qua.`]);
   cases.forEach(b=>{const n=+b.getFieldValue('N');if(n in cs){iss.push(['e',`${tab.name}: CASE ${n} bị trùng.`]);return}
    {const ds=b.getDescendants(false);if(ds.filter(x=>x.type==='jig_once').length>1)iss.push(['e',`${tab.name}, CASE ${n}: chỉ được dùng 1 khối "Khi vào CASE" trong mỗi CASE (gộp các việc vào cùng một khối).`])}
    cs[n]={title:b.getFieldValue('T'),L:stm(b.getInputTargetBlock('BODY'),c)}})}finally{w.dispose()}
  if(!(0 in cs))iss.push(['e',`${tab.name}: cần có CASE 0 (điểm bắt đầu).`]);
  tr[t]=cs});
 if(!tabs.length)iss.push(['w','Chưa có track nào. Bấm "+ Track".']);
 else if(!tabs.some(x=>x.auto))iss.push(['e','Cần ít nhất 1 track tick "Tự chạy khi Start".']);
 if(new Set(tabs.map(x=>x.name)).size<tabs.length)iss.push(['w','Có tên track trùng nhau.']);
 for(const [t,k,w] of c.refs){
  if(k===t&&w==='Gọi')iss.push(['e',`Track ${t} tự gọi chính nó.`]);
  else if(!tabs[k])iss.push(['e',`Track ${t}: ${w} track ${k} nhưng track này không tồn tại.`]);}
 for(const [t,k,w,s] of c.refs)if(w==='Gọi'&&tabs[k]&&!(s in tr[k]))
  iss.push(['e',`Track ${t}: gọi track ${k} từ CASE ${s} nhưng track đích không có CASE ${s}.`]);
 for(const [t,n] of c.gotos)if(!(n in tr[t]))iss.push(['e',`${tabs[t].name}: chuyển sang CASE ${n} nhưng track không có CASE ${n}.`]);
 return {tr,ks:tr.map((_,i)=>i),issues:[...new Set(iss.map(JSON.stringify))].map(JSON.parse)};
}
function outsOf(){const o=[];devices.forEach(d=>{if(d.type==='out'||d.type==='v52')o.push(d.f.addr);if(d.type==='v53')o.push(d.f.a1,d.f.a2)});return o.filter(Boolean).map(x=>x.toUpperCase())}
function gen(r){
 const clk=$('clk').value.trim()||'CR2005',safe=$('safe').value.trim()||'R000';
 const U=r.ks,Ls=[`' Sinh tu Blockly - ${U.length} track`],each=f=>U.forEach(t=>f(t,V(t)));
 Ls.push("' --- Xung 0,1 s ---",`IF ${clk} = ON AND MR101 = OFF THEN`);each((t,v)=>Ls.push(`  DM${v.tm} = DM${v.tm} + 1`));
 Ls.push('END IF',`MR101 = ${clk}`,"' --- Lenh: DM1990 = 1 chay, 2 dung, 3 xoa loi ---",'SELECT CASE DM1990','CASE 1',
  `  IF ${U.map(t=>`DM${V(t).st} <> 1`).join(' AND ')||'MR101 = MR101'} THEN`,'    MR110 = OFF','    MR113 = OFF','    DM1993 = 0','    DM1998 = 0');
 each((t,v)=>Ls.push(`    DM${v.st} = ${tabs[t].auto?1:0}`,`    DM${v.pc} = 0`,`    DM${v.tm} = 0`,`    DM${v.en} = 0`,...axs().map(a=>`    DM${v.ms+a} = 0`)));
 Ls.push('    MR112 = OFF',...motorInit().map(x=>'    '+x));
 Ls.push('  END IF','CASE 2','  MR112 = ON',...motorInit().map(x=>'  '+x));each((t,v)=>Ls.push(`  DM${v.st} = 0`));
 Ls.push('CASE 3','  MR110 = OFF','  MR112 = OFF','  DM1993 = 0','  DM1998 = 0');each((t,v)=>Ls.push(`  DM${v.st} = 0`));
 Ls.push('END SELECT','DM1990 = 0',"' --- An toan ---",`IF ${safe} = OFF THEN`,'  MR110 = ON','  DM1993 = 1','  DM1998 = 0','END IF');
 Ls.push(...motorScan());
 for(const t of U){const v=V(t);
  Ls.push(`' --- TRACK ${t}: ${(tabs[t].name||'').replace(/[^\x20-\x7E]/g,'?')} ---`,`IF MR110 = OFF AND DM${v.st} = 1 THEN`,`  SELECT CASE DM${v.pc}`);
  Object.keys(r.tr[t]).map(Number).sort((a,b)=>a-b).forEach(n=>{Ls.push(`  CASE ${n}`);const L=r.tr[t][n].L;(L.length?L:["' (trong)"]).forEach(x=>Ls.push('    '+x))});
  Ls.push('  CASE ELSE','    MR110 = ON','    DM1993 = 99',`    DM1998 = ${t}`,'  END SELECT','END IF')}
 Ls.push("' --- Loi o bat ky track: dung het ---",'IF MR110 = ON THEN');each((t,v)=>Ls.push(`  DM${v.st} = 3`));Ls.push('END IF');
 const outs=outsOf();
 if(outs.length){Ls.push("' --- Tat output khi loi hoac dung ---",`IF MR110 = ON OR ((${U.map(t=>`DM${V(t).st} = 0`).join(' AND ')||'MR101 = MR101'}) AND MR113 = OFF) THEN`);outs.forEach(a=>Ls.push(`  ${a} = OFF`));Ls.push('END IF')}
 return Ls.join('\n');
}
window.compile=compile;
window.gen=gen;
window.devCheck=devCheck;
window.outsOf=outsOf;
window.syncCur=syncCur;
window.V=V;
window.normM=normM;
})();