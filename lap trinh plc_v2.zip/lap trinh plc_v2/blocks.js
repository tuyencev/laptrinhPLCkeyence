const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const sec=(n,v)=>({type:'field_number',name:n,value:v,min:0,max:6000,precision:0.1});
const ST={previousStatement:null,nextStatement:null};
const LV=[['BẬT (ON)','1'],['TẮT (OFF)','0']];
const COND={type:'input_value',name:'C',check:'Boolean'};
const OPS=[['=','='],['≠','<>'],['>','>'],['≥','>='],['<','<'],['≤','<=']];
const NEG={'=':'<>','<>':'=','>':'<=','<=':'>','>=':'<','<':'>='};
const RA=/^[A-Za-z]{1,2}\d+$/,RD=/^DM\d+$/i;
const DT={
 out:{lab:'Output (đèn/còi/relay)',f:[['addr','Output','R511','o']]},
 v52:{lab:'Van khí nén 5/2',f:[['addr','Cuộn','R508','o'],['home','Home (Input)','R008','i'],['work','Work (Input)','R009','i']]},
 v53:{lab:'Van khí nén 5/3',f:[['a1','Cuộn #1 (lùi)','R509','o'],['a2','Cuộn #2 (tới)','R510','o'],['home','Home (Input)','R010','i'],['work','Work (Input)','R011','i']]},
 motor:{lab:'Motor / trục (xung)',f:[['cw','Xung CW','R500','p'],['ccw','Xung CCW','R501','p'],['servo','Servo ON','R506','o'],['clr','Xóa alarm','R507','o'],['org','Gốc','R000','i'],['stp','Dừng','R001','i'],['alm','Alarm driver','R002','i'],['lcw','Giới hạn CW','R006','i'],['lccw','Giới hạn CCW','R007','i']]},
 in:{lab:'Input rời',f:[['addr','Input','R012','i']]},
 var:{lab:'Biến / counter',f:[['addr','DM','DM100']]}};
const REQ={out:['addr'],v52:['addr'],v53:['a1','a2'],in:['addr'],var:['addr'],motor:[]};
const TAG={home:'Home',work:'Work',a1:'#1',a2:'#2',cw:'CW',ccw:'CCW',servo:'ServoON',clr:'AlarmClr',org:'Gốc',stp:'Dừng',alm:'Alarm',lcw:'LimCW',lccw:'LimCCW'};
let devices=[],tabs=[],act=-1;
const devOf=n=>devices.find(d=>d.name===n);
const listIO=dir=>{const r=[];devices.forEach(d=>{if(!d.name||!DT[d.type])return;DT[d.type].f.forEach(([k,,,x])=>{const a=d.f[k];if(x===dir&&a)r.push([k==='addr'?d.name:d.name+'.'+TAG[k],a.toUpperCase()])})});return r};
const pins=dir=>()=>{const o=listIO(dir).map(x=>[x[0],x[0]]);return o.length?o:[['(chưa khai báo)','']]};
const pinAddr=(dir,n)=>{const x=listIO(dir).find(y=>y[0]===n);return x&&x[1]};
const vl=(d,a)=>d.type==='v52'?[`${d.f.addr} = ${a==='W'?'ON':'OFF'}`]:(m=>[`${d.f.a1} = ${m[0]}`,`${d.f.a2} = ${m[1]}`])({W:['OFF','ON'],H:['ON','OFF'],S:['OFF','OFF']}[a]);
const dv=ty=>()=>{const o=devices.filter(d=>ty.includes(d.type)&&d.name).map(d=>[d.name,d.name]);return o.length?o:[['(chưa khai báo)','']]};
const tn=()=>tabs.length?tabs.map((t,i)=>[t.name||'Track '+i,''+i]):[['(chưa có track)','0']];
const F=o=>new Blockly.FieldDropdown(o),Nf=(v,a,b)=>new Blockly.FieldNumber(v,a,b,1);
const mk=(type,col,kind,f)=>{Blockly.Blocks[type]={init(){f(this);kind==='bool'?this.setOutput(true,'Boolean'):(this.setPreviousStatement(true),this.setNextStatement(true));this.setColour(col)}}};
const D=Blockly.common&&Blockly.common.defineBlocksWithJsonArray||Blockly.defineBlocksWithJsonArray;
const body={type:'input_statement',name:'BODY'};
D([
 {type:'jig_case',message0:'CASE %1  %2',args0:[{type:'field_number',name:'N',value:0,min:0,max:999,precision:1},{type:'field_input',name:'T',text:''}],message1:'%1',args1:[body],colour:210,tooltip:'Một trạng thái của track. Mọi khối bên trong chạy lặp lại mỗi vòng quét cho tới khi bạn "Chuyển sang CASE" khác.'},
 {type:'jig_goto',message0:'Chuyển sang CASE %1',args0:[{type:'field_number',name:'N',value:1,min:0,max:999,precision:1}],...ST,colour:20,tooltip:'Nên đặt cuối CASE: các khối phía sau vẫn chạy nốt trong vòng quét này.'},
 {type:'jig_end',message0:'Kết thúc track (đánh dấu xong)',...ST,colour:20},
 {type:'jig_if',message0:'Nếu %1',args0:[COND],message1:'thì %1',args1:[{type:'input_statement',name:'THEN'}],...ST,colour:20},
 {type:'jig_wait',message0:'Chờ khi %1 , timeout %2 giây',args0:[COND,sec('T',5)],message1:'khi đúng, làm %1',args1:[{type:'input_statement',name:'DO'}],message2:'hết giờ, làm %1',args2:[{type:'input_statement',name:'TO'}],...ST,colour:20,tooltip:'Timeout 0 = mặc định. Nếu "hết giờ" để trống thì báo lỗi 10. Chuyển CASE do bạn quyết định.'},
 {type:'jig_and',message0:'%1 VÀ %2',args0:[{...COND,name:'A'},{...COND,name:'B'}],inputsInline:true,output:'Boolean',colour:210},
 {type:'jig_or',message0:'%1 HOẶC %2',args0:[{...COND,name:'A'},{...COND,name:'B'}],inputsInline:true,output:'Boolean',colour:210},
 {type:'jig_not',message0:'KHÔNG %1',args0:[{...COND,name:'A'}],output:'Boolean',colour:210},
 {type:'jig_timer_ge',message0:'Thời gian trong CASE ≥ %1 giây',args0:[sec('T',1)],output:'Boolean',colour:45},
 {type:'jig_once',message0:'Khi vào CASE (làm 1 lần)',message1:'%1',args1:[body],...ST,colour:60,tooltip:'Chạy đúng 1 lần mỗi khi vào CASE (tăng biến, gọi track, ra lệnh...). Chỉ 1 khối cho mỗi CASE.'},
 {type:'jig_alarm',message0:'Báo lỗi mã %1 (dừng tất cả)',args0:[{type:'field_number',name:'CODE',value:100,min:1,max:65535,precision:1}],...ST,colour:0}
]);
mk('jig_after',45,'stmt',b=>{
 const sourceField=new Blockly.FieldDropdown(()=>[
  ['Nhập số','__number__'],
  ...devices.filter(d=>d.type==='var'&&d.name).map(d=>[d.name,d.name])
 ],value=>{
  const time=b.getField('T');
  if(time)time.setVisible(value==='__number__');
  return value;
 });
 b.appendDummyInput().appendField('Chờ').appendField(sourceField,'SOURCE').appendField(new Blockly.FieldNumber(1,0,6000,0.1),'T').appendField('giây rồi làm');
 b.appendStatementInput('DO').appendField('làm');
 b.setTooltip('Tính từ lúc vào CASE. Nhập số giây hoặc chọn biến DM đã khai báo; giá trị biến được tính bằng giây.');
 const update=()=>b.getField('T').setVisible(b.getFieldValue('SOURCE')==='__number__');
 update();
 b.setOnChange(function(e){
  if(e.type==='change'&&e.blockId===this.id&&e.name==='SOURCE')update();
 });
});
mk('jig_out',160,'stmt',b=>b.appendDummyInput().appendField('Output').appendField(F(pins('o')),'N').appendField('=').appendField(F([['BẬT','1'],['TẮT','0']]),'ST'));
mk('jig_valve',160,'stmt',b=>b.appendDummyInput().appendField('Van').appendField(F(dv(['v52','v53'])),'N').appendField(F([['ra Work (tới)','W'],['về Home (lùi)','H'],['dừng (tắt cuộn)','S']]),'A'));
mk('jig_in',160,'bool',b=>b.appendDummyInput().appendField('Input').appendField(F(pins('i')),'N').appendField('=').appendField(F(LV),'LV'));
mk('jig_valve_at',160,'bool',b=>b.appendDummyInput().appendField('Van').appendField(F(dv(['v52','v53'])),'N').appendField('đang ở').appendField(F([['Home','H'],['Work','W']]),'P'));
mk('jig_valve_go',160,'stmt',b=>{b.appendDummyInput().appendField('Van').appendField(F(dv(['v52','v53'])),'N').appendField(F([['ra Work (tới)','W'],['về Home (lùi)','H']]),'A').appendField('timeout').appendField(new Blockly.FieldNumber(5,0,6000,0.1),'T').appendField('giây');
 b.appendStatementInput('DO').appendField('khi tới nơi, làm');b.appendStatementInput('TO').appendField('hết giờ, làm')});
mk('jig_mgo',160,'stmt',b=>{b.appendDummyInput().appendField('Motor').appendField(F(dv(['motor'])),'N').appendField('tới điểm').appendField(Nf(1,1,20),'P').appendField('timeout').appendField(new Blockly.FieldNumber(10,0,6000,0.1),'T').appendField('giây');
 b.appendStatementInput('DO').appendField('khi tới nơi, làm');b.appendStatementInput('TO').appendField('hết giờ, làm')});
mk('jig_mhome',160,'stmt',b=>{b.appendDummyInput().appendField('Motor').appendField(F(dv(['motor'])),'N').appendField('về gốc (ORG), timeout').appendField(new Blockly.FieldNumber(30,0,6000,0.1),'T').appendField('giây');
 b.appendStatementInput('DO').appendField('khi về gốc xong, làm');b.appendStatementInput('TO').appendField('hết giờ, làm')});
mk('jig_mhome2',160,'stmt',b=>{b.appendDummyInput().appendField('Motor').appendField(F(dv(['motor'])),'N').appendField('về HOME (HOME), timeout').appendField(new Blockly.FieldNumber(30,0,6000,0.1),'T').appendField('giây');
 b.appendStatementInput('DO').appendField('khi xong, làm');b.appendStatementInput('TO').appendField('hết giờ, làm')});
mk('jig_servo',160,'stmt',b=>b.appendDummyInput().appendField('Motor').appendField(F(dv(['motor'])),'N').appendField('Servo').appendField(F([['BẬT','1'],['TẮT','0']]),'ST'));
mk('jig_motor_is',160,'bool',b=>b.appendDummyInput().appendField('Motor').appendField(F(dv(['motor'])),'N').appendField(F([['ở gốc','org'],['chạm giới hạn CW','lcw'],['chạm giới hạn CCW','lccw'],['driver báo lỗi','alm']]),'P'));
mk('jig_start_trk',330,'stmt',b=>b.appendDummyInput().appendField('Gọi track').appendField(F(tn),'TRK').appendField('chạy từ CASE').appendField(Nf(0,0,999),'CASE'));
mk('jig_trk_is',330,'bool',b=>b.appendDummyInput().appendField('Track').appendField(F(tn),'TRK').appendField(F([['đang chạy','1'],['đã xong','2'],['đang lỗi','3']]),'M'));
mk('jig_trk_case',330,'bool',b=>b.appendDummyInput().appendField('Track').appendField(F(tn),'TRK').appendField('đang ở CASE').appendField(Nf(0,0,999),'N'));
mk('jig_set_var',290,'stmt',b=>b.appendDummyInput().appendField('Biến').appendField(F(dv(['var'])),'V').appendField('=').appendField(Nf(0,0,65535),'N'));
mk('jig_inc_var',290,'stmt',b=>b.appendDummyInput().appendField('Biến').appendField(F(dv(['var'])),'V').appendField('tăng thêm').appendField(Nf(1,0,65535),'N'));
mk('jig_var_cmp',290,'bool',b=>b.appendDummyInput().appendField('Biến').appendField(F(dv(['var'])),'V').appendField(F(OPS),'OP').appendField(Nf(0,0,65535),'N'));


/* ===== Motor bước (AccelStepper) + LCD I2C cho gencode_mega.js =====
 * Dán xuống CUỐI blocks.js (hoặc nạp sau blocks.js): dùng lại $, F, Nf, dv, mk, DT, REQ có sẵn ở đó.
 * Toolbox thêm: jig_step_go, jig_step_home, jig_step_stop, jig_lcd_text, jig_lcd_var, jig_lcd_clear
 */

/* ===== LCD I2C cho gencode_mega.js (viết theo kiểu blocks.js) =====
 * Dán xuống CUỐI blocks.js (hoặc nạp sau blocks.js): dùng lại F, Nf, dv, mk, DT, REQ có sẵn ở đó.
 * Motor bước dùng chung khai báo `motor` và các block jig_mgo / jig_mhome / jig_mhome2 / jig_servo / jig_motor_is của PLC, không cần block mới.
 * Toolbox thêm: jig_lcd_text, jig_lcd_var, jig_lcd_clear
 */
Object.assign(DT,{
 lcd:{lab:'LCD I2C (chiếm D20/D21)',f:[['addr','Địa chỉ I2C','0x27'],['cols','Số cột (16/20)','16'],['rows','Số hàng (2/4)','2']]}});
Object.assign(REQ,{lcd:['addr']});

// LCD chỉ ghi lại ký tự thay đổi nên đặt trong CASE chạy lặp cũng được
mk('jig_lcd_text',120,'stmt',b=>{b.appendDummyInput().appendField('LCD hàng').appendField(Nf(0,0,3),'R').appendField('cột').appendField(Nf(0,0,19),'C').appendField('hiện').appendField(new Blockly.FieldTextInput('Hello'),'TXT');
 b.setTooltip('Chỉ ký tự ASCII (không dấu). Muốn xóa chữ cũ thì thêm khoảng trắng ở cuối.')});
mk('jig_lcd_var',120,'stmt',b=>b.appendDummyInput().appendField('LCD hàng').appendField(Nf(0,0,3),'R').appendField('cột').appendField(Nf(0,0,19),'C').appendField('hiện biến').appendField(F(dv(['var'])),'V').appendField('rộng').appendField(Nf(5,1,6),'W').appendField('ký tự'));
mk('jig_lcd_clear',120,'stmt',b=>b.appendDummyInput().appendField('LCD xóa màn hình'));

/* ===== Motor không chổi than (BLDC): driver 3 chân (Brake, REV, FWD) hoặc 2 chân (Brake, REV/FWD), có Alarm ===== */
Object.assign(DT,{
 bldc:{lab:'Motor không chổi than (BLDC)',f:[['brk','Chân Brake','','o'],['fwd','Chân FWD','','o'],['rev','Chân REV','','o'],['alm','Alarm driver (vào)','','i'],
  ['head','Cảm biến Đầu','','i'],['end','Cảm biến Cuối','','i'],['start','Nút Start','','i'],['pause','Nút Tạm dừng','','i']]}});
Object.assign(REQ,{bldc:['brk','fwd']});
Object.assign(TAG,{brk:'Brake',fwd:'FWD',rev:'REV',head:'Đầu',end:'Cuối',start:'Start',pause:'TạmDừng'});
mk('jig_bldc',160,'stmt',b=>b.appendDummyInput().appendField('BLDC').appendField(F(dv(['bldc'])),'N').appendField(F([['Tiến','1'],['Lùi','2'],['Dừng (thả)','0'],['Brake (hãm)','3']]),'A'));
mk('jig_bldc_go',160,'stmt',b=>{b.appendDummyInput().appendField('BLDC').appendField(F(dv(['bldc'])),'N').appendField(F([['Chạy Tiến-->CB_Cuối','1'],['chạy Lùi-->CB_Đầu','2']]),'A').appendField('timeout').appendField(new Blockly.FieldNumber(10,0,6000,0.1),'T').appendField('giây');
 b.appendStatementInput('DO').appendField('khi tới nơi, làm');b.appendStatementInput('TO').appendField('hết giờ, làm')});
mk('jig_bldc_is',160,'bool',b=>b.appendDummyInput().appendField('BLDC').appendField(F(dv(['bldc'])),'N').appendField(F([['Chạm CB_Đầu','head'],['chạm CB_Cuối','end'],['Start_on ','start'],['Tạm dừng on','pause'],['driver báo lỗi (Alarm)','alm']]),'P'));