const controllerType=()=>$('controller').value;
const isMega=()=>controllerType()==='plc_arduino'||controllerType()==='mega';   // bộ sinh Arduino Mega
const isMcu=()=>controllerType()==='pic'||isMega();
let shownController=controllerType();
function updateControllerUI(){
 const pic=isMcu(),mega=isMega();
 document.title=mega?'Blockly sinh mã Arduino Mega 2560':pic?'Blockly sinh mã PIC CCS C':'Blockly sinh KV Script KV-N60AT';
 $('appTitle').textContent=mega?'Lập trình Arduino Mega':pic?'Lập trình PIC':'Lập trình PLC KV';
 $('bcopy').textContent=mega?'Sao chép mã Arduino':pic?'Sao chép mã PIC':'Sao chép KV Script';
 $('scriptTitle').textContent=mega?'Mã nguồn Arduino Mega 2560 (.ino)':pic?'Mã nguồn PIC CCS C':'KV Script (dán vào KV STUDIO)';
 $('clksetting').style.display=pic?'none':'';
 $('safeLabel').textContent=mega?'Tín hiệu an toàn (tên Input hoặc Dnn/Ann)':pic?'Tín hiệu an toàn (tên Input hoặc PIN_xx)':'Tín hiệu an toàn (ON = OK)';
 $('safe').placeholder=pic?'Để trống nếu không dùng':'R015';
 $('cfgHint').textContent=mega
  ?'Arduino Mega 2560: chân số D2–D53, chân analog A0–A15 dùng như chân số. D0/D1 dành cho Serial USB, D30/D31/D32 cho 74HC595 (DATA/CLK/LATCH), D20/D21 cho I2C khi có LCD. Output dùng chân Dnn hoặc 74HC595 (595:0–23). Motor dùng chung khai báo với PLC: Xung CW = chân STEP, Xung CCW = chân DIR (driver STEP/DIR); bảng điểm: tọa độ = bước, tốc độ = bước/s, gia tốc [Hz/ms] x 1000 = bước/s² (giảm tốc dùng chung gia tốc); về gốc chạy chiều âm tới cảm biến Gốc (ORG).'
  :pic
  ?'PIC dùng chân GPIO phù hợp với mạch; C3–C5 dành cho 74HC595 và C6–C7 cho UART. Output có thể dùng chân PIN_xx hoặc 74HC595 (595:0–23); chọn chân trong cấu hình thiết bị. Biến là tên biến C hợp lệ. Motor/Servo chưa được bộ sinh PIC hỗ trợ.'
  :'Khai báo theo sơ đồ đấu dây Keyence (trục 1: R500/R501 xung, R506 Servo ON, R507 xóa alarm, R000-R002 gốc/dừng/alarm, R006/R007 giới hạn). Biến dùng DM, tránh DM1990-DM2149.';
 $('outputHint').textContent=mega
  ?'Mã .ino cho Arduino Mega 2560. Cần thư viện AccelStepper (nếu có motor) và LiquidCrystal_I2C (nếu có LCD). Dán vào Arduino IDE, chọn board Mega 2560, biên dịch và nạp.'
  :pic
  ?'Mã sinh theo CCS C cho PIC16F877A; kiểm tra cấu hình chân và thư viện/phần cứng trước khi biên dịch, nạp vào PIC.'
  :'Dán vào vùng Script trong KV STUDIO, biên dịch, nạp PLC. Giám sát: DM1990 lệnh (1 chạy, 2 dừng, 3 xóa lỗi); track t: DM(2000+10t) trạng thái (0 dừng, 1 chạy, 2 xong, 3 lỗi), +1 CASE hiện tại, +3 timer; DM1993 mã lỗi, DM1998 track lỗi, MR110 cờ lỗi.';
 $('scada').onclick=()=>{
  if(dashWin&&!dashWin.closed){sendCfg();dashWin.focus();return}   // đã mở: chỉ cần đẩy lại cấu hình
  dashWin=window.open(mega?'mega_jig_dashboard.html':pic?'pic_jig_dashboard.html':'kv_jig_dashboard.html','jigDash');
  if(!dashWin)alert('Trình duyệt chặn cửa sổ mới. Hãy cho phép cửa sổ bật lên cho trang này.')};
}
function render(){
 const r=compile(),err=r.issues.some(i=>i[0]==='e');
 $('issues').innerHTML=r.issues.length?r.issues.map(i=>`<div class="msg ${i[0]}">${esc(i[1])}</div>`).join(''):'<div class="msg o">Không có lỗi.</div>';
 let h='';
 for(const t of r.ks){const v=V(t),cs=Object.keys(r.tr[t]).map(Number).sort((a,b)=>a-b);
  const monitor=isMcu()?'Track '+t+': trạng thái, CASE và timer (tick 100 ms)':'DM'+v.st+' trạng thái, DM'+v.pc+' CASE hiện tại, DM'+v.tm+' timer (0,1 s)';
  h+=`<h2>Track ${t} "${esc(tabs[t].name)}"</h2><p class="hint">${monitor}</p><table><tr><th>CASE</th><th>Tên</th><th>Số dòng code</th></tr>`;
  cs.forEach(n=>h+=`<tr><td class="n">${n}</td><td>${esc(r.tr[t][n].title)}</td><td class="n">${r.tr[t][n].L.length}</td></tr>`);h+='</table>'}
 $('steps').innerHTML=h||'<p class="hint">Chưa có track nào.</p>';
 $('script').value=gen(r);$('bcopy').disabled=err||!r.ks.length;updPanel(r.issues.filter(i=>i[0]==='e').length);
}
function updPanel(n){const sh=document.querySelector('main').classList.contains('show'),b=$('bpanel');b.textContent=(sh?'Kết quả ◂':'Kết quả ▸')+(n?` (${n} lỗi)`:'');b.style.color=n?'#b3261e':'';b.style.borderColor=n?'#b3261e':''}
$('bpanel').onclick=()=>{document.querySelector('main').classList.toggle('show');render();setTimeout(()=>Blockly.svgResize(ws),50)};
const KEY='jigPlcGen4';
let profiles={};
const clone=value=>JSON.parse(JSON.stringify(value));
function currentProfile(){syncCur();return {devices,tabs,deft:$('deft').value,clk:$('clk').value,safe:$('safe').value}}
function createProfile(type,source){
 const p=clone(source),isM=type==='mega'||type==='plc_arduino',isPic=type==='pic'||isM;
 p.devices=p.devices.filter(d=>(!isPic||isM||d.type!=='motor')&&(isM||(d.type!=='lcd'&&d.type!=='bldc')));
 const mIn=['D22','D23','D24','D25','D26','D27','D28','D29','D33','D34','D35','D36','D37'],mOut=Array.from({length:16},(_,i)=>'D'+(38+i)),mPulse=['D2','D3','D4','D5','D6','D7','D8','D9'];
 const inputPins=isM?mIn:isPic
  ?['PIN_B0','PIN_B1','PIN_B2','PIN_B3','PIN_B4','PIN_B5','PIN_B6','PIN_B7','PIN_A0','PIN_A1','PIN_A2','PIN_A3','PIN_A4','PIN_A5','PIN_E0','PIN_E1','PIN_E2']
  :Array.from({length:80},(_,i)=>'R'+String(20+i).padStart(3,'0'));
 const outputPins=isM?mOut:isPic
  ?['PIN_D0','PIN_D1','PIN_D2','PIN_D3','PIN_D4','PIN_D5','PIN_D6','PIN_D7','PIN_C0','PIN_C1','PIN_C2']
  :Array.from({length:80},(_,i)=>'R'+String(511-i).padStart(3,'0'));
 let inputIndex=0,outputIndex=0,pulseIndex=0,varIndex=100;
 p.devices.forEach(d=>{
  DT[d.type].f.forEach(([key,,,direction])=>{
   if(direction==='i')d.f[key]=inputPins[inputIndex++]||'';
   else if(direction==='p'&&isM)d.f[key]=mPulse[pulseIndex++]||'';
   else if(direction==='o')d.f[key]=outputPins[outputIndex++]||(isM?'595:'+(outputIndex-mOut.length-1):isPic?'595:'+(outputIndex-12):'R'+(511+outputIndex-80));
  });
  if(d.type==='var')d.f.addr=isPic?(d.name.replace(/[^A-Za-z0-9_]/g,'_').replace(/^[^A-Za-z_]+/,'')||'value'):'DM'+varIndex++;
 });
 p.clk='CR2005';
 p.safe=isPic?'':'R015';
 return p;
}
let dashWin=null;
const sendCfg=()=>{try{dashWin.postMessage({type:'jig-cfg',payload:JSON.parse(JSON.stringify(snap())),name:'kich_ban_jig.json'},'*')}catch(e){}};
window.addEventListener('message',e=>{if(e.data&&e.data.type==='jig-cfg-ready'&&dashWin&&e.source===dashWin)sendCfg()});
const snap=()=>{
 const active=currentProfile();profiles[controllerType()]=clone(active);
 return {controller:controllerType(),...active,profiles:clone(profiles)};
};
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(snap()))}catch(e){}};


function ptsHTML(d){const H=['Điểm','Tọa độ đích [PLS]<br>CM+0/1','Gia tốc [Hz/ms]<br>CM+2','Giảm tốc [Hz/ms]<br>CM+3','Tốc độ [Hz]<br>CM+4/5'],K=['tg','ac','de','sp'];
 return '<table class="pt"><tr>'+H.map(x=>`<th>${x}</th>`).join('')+'</tr>'+(d.rows||[]).map((o,i)=>`<tr><td>${i+1}</td>`+K.map(k=>`<td><input data-r="${i}" data-c="${k}" value="${esc((o&&o[k])||'')}"></td>`).join('')+'</tr>').join('')+'</table><button class="ghost" data-add>+ Điểm</button> <button class="ghost" data-del>− Điểm cuối</button> <span class="hint">Nhập số thập phân đọc từ KV STUDIO (Watch, DEC). Ô trống = không ghi, giữ giá trị cài trong KV STUDIO.</span>'}


 const GR=[['io','Output / Input',['out','in']],['valve','Van khí nén',['v52','v53']],['motor','Motor / trục',['motor']],['var','Biến / counter',['var']],['bldc','Motor không chổi than (BLDC)',['bldc']],['lcd','LCD I2C',['lcd']]],gopen={};
function addDev(k){let n=1;while(devices.some(d=>d.name===k+'_'+n))n++;devices.push({type:k,name:k+'_'+n,f:Object.fromEntries(DT[k].f.map(f=>[f[0],isMcu()&&/^(R|DM)\d+$/i.test(f[2])?'':f[2]])),...(k==='motor'?{axis:'1',orgp:'',rows:[{tg:'20'}]}:{}),...(k==='bldc'?{mode:'3'}:{})});drawDevs();render();save()}
 const LABM={cw:'Chân STEP (xung)',ccw:'Chân DIR (hướng)',servo:'Chân ENABLE / Servo ON',clr:'Chân xóa alarm',org:'Cảm biến Gốc (ORG)',stp:'Nút Dừng',alm:'Alarm driver',lcw:'Giới hạn CW',lccw:'Giới hạn CCW'};
 const megaPins=[...Array.from({length:52},(_,i)=>'D'+(i+2)),...Array.from({length:16},(_,i)=>'A'+i)];
 const picPins=(()=>{const pins=[];for(const port of ['A','B','C','D','E']){const max=port==='E'?2:port==='A'?5:7;for(let i=0;i<=max;i++)if(port!=='C'||i<3)pins.push('PIN_'+port+i)}return pins})();
 const pinListId=dir=>dir==='o'?'pic-output-pins':'pic-input-pins';
 function drawDevs(){
  const box=$('devs');box.innerHTML='';
  if(isMcu())box.innerHTML='<datalist id="pic-input-pins">'+(isMega()?megaPins:picPins).map(p=>`<option value="${p}">`).join('')+'</datalist><datalist id="pic-output-pins">'+(isMega()?megaPins:picPins).map(p=>`<option value="${p}">`).join('')+Array.from({length:24},(_,i)=>`<option value="595:${i}">`).join('')+'</datalist>';
  GR.forEach(([gid,lab,types])=>{if((gid==='lcd'||gid==='bldc')&&!isMega())return;
  const list=devices.map((d,i)=>[d,i]).filter(([d])=>types.includes(d.type)),g=document.createElement('details');
  g.className='grp';g.open=gopen[gid]!==false;g.ontoggle=()=>{gopen[gid]=g.open};
  g.innerHTML=`<summary>${lab} <span class="hint">(${list.length})</span></summary><div class="gbody"></div><div class="gadd"></div>`;
  const gb=g.querySelector('.gbody');
  list.forEach(([d,i])=>{const r=document.createElement('div');r.className='dev';
   r.innerHTML=`<span class="t">${DT[d.type].lab}</span><input class="nm" value="${esc(d.name)}" placeholder="Tên">`+DT[d.type].f.filter(f=>!(d.type==='bldc'&&d.mode==='2'&&f[0]==='rev')).map(f=>`<label>${(isMega()&&d.type==='motor'&&LABM[f[0]])||(d.type==='bldc'&&d.mode==='2'&&f[0]==='fwd'?'Chân REV/FWD (DIR)':f[1])} <input data-k="${f[0]}" value="${esc(d.f[f[0]]||'')}"${isMcu()&&f[3]?` list="${pinListId(f[3])}"`:''}></label>`).join('')+(d.type==='bldc'?`<label>Loại driver <select data-x="mode"><option value="3"${d.mode!=='2'?' selected':''}>3 chân (Brake, REV, FWD)</option><option value="2"${d.mode==='2'?' selected':''}>2 chân (Brake, REV/FWD)</option></select></label>`:'')+(d.type==='motor'?`<label>Trục (1-4) <input data-x="axis" value="${esc(d.axis||'1')}" style="width:40px"></label><label>Về gốc (tốc_độ_bắt_đầu gia_tốc giảm_tốc tốc_độ [CM8814 tùy chọn]) <input data-x="orgp" value="${esc(d.orgp||'')}" style="width:230px"></label><details class="sub" open><summary>Bảng điểm (CM)</summary><div class="pts">${ptsHTML(d)}</div></details>`:'')+'<button class="ghost" data-xdev>Xóa</button>';
   r.querySelector('.nm').oninput=e=>{d.name=e.target.value.trim();render();save()};
   r.querySelectorAll('[data-k]').forEach(x=>x.oninput=e=>{d.f[x.dataset.k]=e.target.value.trim().toUpperCase();render();save()});
   r.querySelectorAll('[data-x]').forEach(x=>x.oninput=e=>{d[x.dataset.x]=e.target.value;if(d.type==='bldc'&&x.dataset.x==='mode'){if(d.mode==='2')d.f.rev='';drawDevs()}render();save()});
   r.querySelectorAll('[data-c]').forEach(x=>x.oninput=e=>{d.rows[+x.dataset.r][x.dataset.c]=e.target.value.trim();render();save()});
   const ba=r.querySelector('[data-add]'),bd=r.querySelector('[data-del]');
   if(ba)ba.onclick=()=>{if(d.rows.length<20)d.rows.push({});drawDevs();render();save()};
   if(bd)bd.onclick=()=>{if(d.rows.length>1)d.rows.pop();drawDevs();render();save()};
   r.querySelector('[data-xdev]').onclick=()=>{devices.splice(i,1);drawDevs();render();save()};
   gb.appendChild(r)});
  const ga=g.querySelector('.gadd');types.forEach(k=>{const b=document.createElement('button');b.className='ghost';b.textContent='+ '+DT[k].lab;b.disabled=controllerType()==='pic'&&!isMega()&&k==='motor';b.title=b.disabled?'Khối motor chưa được hỗ trợ bởi bộ sinh PIC':'';b.onclick=()=>addDev(k);ga.appendChild(b)});
  box.appendChild(g)});
}
function drawTabs(){
 const n=$('tabs');n.innerHTML='';
 const add=(txt,on,fn)=>{const b=document.createElement('button');b.className='tab'+(on?' on':'');b.textContent=txt;b.onclick=fn;n.appendChild(b)};
 add('⚙ Cấu hình',act<0,()=>go(-1));
 tabs.forEach((t,i)=>add(t.name||'Track '+i,act===i,()=>go(i)));
 if(tabs.length<15)add('+ Track',false,()=>{tabs.push({name:'Track '+tabs.length,auto:!tabs.length,state:null});go(tabs.length-1);save()});
}
function go(i){
 syncCur();act=i;drawTabs();
 const cfg=i<0;$('cfg').style.display=cfg?'block':'none';$('ws').style.display=cfg?'none':'block';$('trkbar').style.display=cfg?'none':'flex';
 if(!cfg){const t=tabs[i];$('tname').value=t.name;$('tauto').checked=t.auto;
  Blockly.Events.disable();try{ws.clear();if(t.state)Blockly.serialization.workspaces.load(t.state,ws)}finally{Blockly.Events.enable()}
  Blockly.svgResize(ws)}
 render();
}
ws.addChangeListener(e=>{if(e.isUiEvent||act<0)return;render();save()});
['deft','clk','safe'].forEach(i=>$(i).addEventListener('input',()=>{render();save()}));
$('tname').oninput=()=>{tabs[act].name=$('tname').value;drawTabs();render();save()};
$('tauto').onchange=()=>{tabs[act].auto=$('tauto').checked;render();save()};
$('tdel').onclick=()=>{if(!confirm('Xóa track này? Các khối tham chiếu theo số thứ tự track sẽ bị lệch.'))return;const k=act;act=-1;tabs.splice(k,1);go(tabs.length?Math.min(k,tabs.length-1):-1);save()};
$('bcopy').onclick=async()=>{try{await navigator.clipboard.writeText($('script').value)}catch(e){$('script').select();document.execCommand('copy')}
 $('bcopy').textContent='Đã sao chép';setTimeout(()=>$('bcopy').textContent=isMega()?'Sao chép mã Arduino':controllerType()==='pic'?'Sao chép mã PIC':'Sao chép KV Script',1500)};
$('bsave').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(snap())],{type:'application/json'}));a.download='kich_ban_jig.json';a.click()};
$('bopen').onclick=()=>$('fopen').click();
function applyData(o){if(o.profiles&&typeof o.profiles==='object')profiles=o.profiles;devices=(o.devices||[]).map(d=>d.type==='motor'?normM(d):d.type==='bldc'?{mode:'3',...d}:d);tabs=o.tabs||[];if(o.deft)$('deft').value=o.deft;if(o.clk)$('clk').value=o.clk;if(Object.prototype.hasOwnProperty.call(o,'safe'))$('safe').value=o.safe;drawDevs();go(tabs.length?0:-1);updateControllerUI();save()}
function apply(o){
 if(o.controller&&o.controller!==controllerType()){
  window.loadController(o.controller).then(()=>applyData(o)).catch(error=>alert(error.message));
  return;
 }
 applyData(o);
}
$('fopen').onchange=e=>{const f=e.target.files[0];if(!f)return;const R=new FileReader();R.onload=()=>{try{apply(JSON.parse(R.result))}catch(x){alert('File .json không hợp lệ')}};R.readAsText(f);e.target.value=''};
const B=(type,fields,inputs)=>({type,fields,inputs}),ch=a=>{let n=null;for(let i=a.length-1;i>=0;i--)n={block:{...a[i],...(n?{next:n}:{})}};return n.block};
const CS=(n,title,a)=>B('jig_case',{N:n,T:title},{BODY:{block:ch(a)}});
const TS=n=>B('jig_timer_ge',{T:n}),IFT=(s,a)=>B('jig_if',{},{C:{block:TS(s)},THEN:{block:ch(a)}}),GO=n=>B('jig_goto',{N:n});
const S=a=>({blocks:{languageVersion:0,blocks:a.map((c,i)=>({...c,x:30,y:30+i*230}))}});
const dev=(type,name,f)=>({type,name,f});
let init=null;try{init=JSON.parse(localStorage.getItem(KEY))}catch(e){}
if(init&&init.tabs)apply(init);
else apply({controller:controllerType(),devices:isMega()
 ?[dev('out','Den_bao',{addr:'D38'}),dev('v52','Van_kep',{addr:'D39',home:'D24',work:'D25'}),dev('v53','Van_day',{a1:'D40',a2:'D41',home:'D26',work:'D27'}),dev('in','Cam_phoi',{addr:'D22'}),dev('var','San_luong',{addr:'San_luong'})]
 :controllerType()==='pic'
 ?[dev('out','Den_bao',{addr:'PIN_D0'}),dev('v52','Van_kep',{addr:'PIN_D1',home:'PIN_B2',work:'PIN_B3'}),dev('v53','Van_day',{a1:'PIN_D2',a2:'PIN_D3',home:'PIN_B4',work:'PIN_B5'}),dev('in','Cam_phoi',{addr:'PIN_B1'}),dev('var','San_luong',{addr:'San_luong'})]
 :[dev('out','Den_bao',{addr:'R511'}),dev('v52','Van_kep',{addr:'R508',home:'R008',work:'R009'}),dev('v53','Van_day',{a1:'R509',a2:'R510',home:'R010',work:'R011'}),
   dev('in','Cam_phoi',{addr:'R012'}),dev('motor','Truc_1',{cw:'R500',ccw:'R501',servo:'R506',clr:'R507',org:'R000',stp:'R001',alm:'R002',lcw:'R006',lccw:'R007'}),dev('var','San_luong',{addr:'DM100'})],
 safe:controllerType()==='pic'?'':'R015',
 tabs:[
 {name:'Chính',auto:true,state:S([
  CS(0,'Kẹp',[B('jig_valve',{N:'Van_kep',A:'W'}),IFT(2,[GO(1)])]),
  CS(1,'Đẩy',[B('jig_valve',{N:'Van_day',A:'W'}),IFT(2,[GO(2)])]),
  CS(2,'Về',[B('jig_valve',{N:'Van_day',A:'H'}),B('jig_valve',{N:'Van_kep',A:'H'}),IFT(2,[B('jig_inc_var',{V:'San_luong',N:1}),GO(0)])])])},
 {name:'Đèn báo',auto:true,state:S([
  CS(0,'Sáng',[B('jig_out',{N:'Den_bao',ST:'1'}),IFT(.5,[GO(1)])]),
  CS(1,'Tắt',[B('jig_out',{N:'Den_bao',ST:'0'}),IFT(.5,[GO(0)])])])}]});
updateControllerUI();
document.addEventListener('controller-loaded',e=>{
 const next=e.detail,prev=shownController;
 if(prev!==next){
  profiles[prev]=clone(currentProfile());
  const target=profiles[next]||createProfile(next,profiles[prev]);
  devices=clone(target.devices);tabs=clone(target.tabs);$('deft').value=target.deft||'10';$('clk').value=target.clk||'CR2005';$('safe').value=target.safe||'';
  act=-1;
  shownController=next;
 }
 updateControllerUI();drawDevs();go(tabs.length?0:-1);save();
});